<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $transaction_id = $_POST['transaction_id'] ?? null;

    try {
        // Verify ownership before deletion
        $stmt = $conn->prepare("DELETE FROM transactions 
                              WHERE transaction_id = ? 
                              AND user_id = ?");
        $stmt->bind_param("ii", $transaction_id, $user_id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            $_SESSION['success'] = "Transaction deleted successfully";
        } else {
            $_SESSION['error'] = "Transaction not found or access denied";
        }
    } catch (mysqli_sql_exception $e) {
        $_SESSION['error'] = "Error deleting transaction: " . $e->getMessage();
    }
}

header("Location: transaction.php");
exit();
?>