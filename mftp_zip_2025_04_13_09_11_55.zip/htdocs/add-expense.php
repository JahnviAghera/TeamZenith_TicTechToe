<?php
session_start();
require_once('config.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$error = '';
$success = '';
$categories = [];

// Fetch user data
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$user = $user_result->fetch_assoc();
$stmt->close();

// Fetch categories from database
$category_stmt = $conn->prepare("SELECT * FROM categories WHERE user_id = ? OR is_default = 1");
$category_stmt->bind_param("i", $user_id);
$category_stmt->execute();
$categories = $category_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$category_stmt->close();

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate required fields
        $required = ['description', 'amount', 'category_id', 'payment_method'];
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("All fields marked with * are required");
            }
        }

        // Sanitize inputs
        $description = htmlspecialchars($_POST['description']);
        $amount = (float)$_POST['amount'];
        $category_id = (int)$_POST['category_id'];
        $payment_method = htmlspecialchars($_POST['payment_method']);
        $transaction_date = date('Y-m-d');

        // Validate category exists
        $valid_category = false;
        foreach ($categories as $cat) {
            if ($cat['category_id'] == $category_id) {
                $valid_category = true;
                break;
            }
        }
        if (!$valid_category) {
            throw new Exception("Invalid category selected");
        }

// Insert transaction
$stmt = $conn->prepare("INSERT INTO transactions 
    (user_id, category_id, amount, description, transaction_date, transaction_type, payment_method) 
    VALUES (?, ?, ?, ?, ?, 'expense', ?)");
$stmt->bind_param("iidsss", 
    $user_id, 
    $category_id, 
    $amount, 
    $description, 
    $transaction_date, 
    $payment_method
);
        if (!$stmt->execute()) {
            throw new Exception("Error saving transaction: " . $stmt->error);
        }

// Change this:
$success = "Expense added successfully!";
header("dashboard.php");
$_POST = []; // Clear form fields

// To this:
$_SESSION['success'] = "Expense added successfully!";
header("Location: dashboard.php");
exit();
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Expense - SpendWise</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0">
  <style>
    .blue-monotone {
      background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
    }
    .progress-bar {
      transition: width 0.5s ease-in-out;
    }
    .input-focus-effect:focus {
      box-shadow: 0 0 0 3px rgba(30, 58, 138, 0.3);
    }
    /* Improved mobile tap targets */
    @media (max-width: 640px) {
      .mobile-tap-target {
        min-height: 48px;
        padding: 12px 16px;
      }
      .mobile-text-lg {
        font-size: 1.125rem;
      }
    }
  </style>
</head>
<body class="bg-blue-50 min-h-screen p-4 pb-24 md:pb-4">

  <!-- Header -->
  <div class="flex justify-between items-center mb-6">
    <div>
      <h1 class="text-2xl font-bold text-blue-900 mobile-text-lg">Add New Expense</h1>
      <p class="text-blue-600 text-sm md:text-base">Track your spending effortlessly</p>
    </div>
    <!-- Profile Dropdown -->
    <div class="relative group" id="profileDropdown">
      <div class="w-10 h-10 rounded-full bg-blue-100 overflow-hidden flex items-center justify-center cursor-pointer shadow-sm">
        <?php if ($user['profile_image']): ?>
          <img src="<?= htmlspecialchars($user['profile_image']) ?>" class="w-full h-full object-cover">
        <?php else: ?>
          <span class="text-blue-800 font-semibold"><?= strtoupper(substr($user['first_name'], 0, 1)) ?></span>
        <?php endif; ?>
      </div>
      <!-- Dropdown Menu -->
      <div class="absolute right-0 mt-2 w-48 bg-white border border-blue-100 rounded-lg shadow-xl opacity-0 invisible transition-all duration-300 z-50" 
           id="profileMenu">
        <a href="profile.php" class="block px-4 py-3 text-blue-800 hover:bg-blue-50 mobile-tap-target">Profile</a>
        <a href="settings.php" class="block px-4 py-3 text-blue-800 hover:bg-blue-50 mobile-tap-target">Settings</a>
        <form method="POST" action="logout.php">
          <button type="submit" class="w-full text-left px-4 py-3 text-blue-800 hover:bg-blue-50 border-t border-blue-100 mobile-tap-target">
            Logout
          </button>
        </form>
      </div>
    </div>
  </div>

  <!-- Main Form -->
  <div class="max-w-2xl mx-auto w-full">
    <?php if ($error): ?>
      <div class="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
        <span class="material-symbols-rounded text-red-500">error</span>
        <?= $error ?>
      </div>
    <?php endif; ?>

    <form method="POST" class="bg-white p-4 md:p-6 rounded-xl shadow-lg border border-blue-100">
      <div class="space-y-4">
        <!-- Description Input -->
        <div>
          <label class="block text-sm font-medium text-blue-700 mb-2">
            Description*
          </label>
          <input type="text" name="description" required 
                class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect mobile-tap-target"
                value="<?= htmlspecialchars($_POST['description'] ?? '') ?>">
        </div>

        <!-- Amount Input -->
        <div>
          <label class="block text-sm font-medium text-blue-700 mb-2">
            Amount*
          </label>
          <input type="number" step="0.01" name="amount" required
                class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect mobile-tap-target"
                value="<?= htmlspecialchars($_POST['amount'] ?? '') ?>">
        </div>

        <!-- Category Selector -->
        <div class="relative">
          <label class="block text-sm font-medium text-blue-700 mb-2">
            Category*
          </label>
          <div class="relative">
            <select name="category_id" required 
                   class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect mobile-tap-target">
              <option value="">Select Category</option>
              <?php foreach ($categories as $category): ?>
                <option value="<?= $category['category_id'] ?>" <?= ($_POST['category_id'] ?? '') == $category['category_id'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($category['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <!-- Payment Method -->
        <div>
          <label class="block text-sm font-medium text-blue-700 mb-2">
            Payment Method*
          </label>
          <select name="payment_method" required 
                 class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect mobile-tap-target">
            <option value="" disabled selected>Select payment method</option>
            <optgroup label="Digital Payments">
              <option value="UPI" <?= ($_POST['payment_method'] ?? '') == 'UPI' ? 'selected' : '' ?>>UPI (PhonePe, GPay, etc.)</option>
              <option value="Net Banking" <?= ($_POST['payment_method'] ?? '') == 'Net Banking' ? 'selected' : '' ?>>Net Banking</option>
              <option value="Mobile Wallet" <?= ($_POST['payment_method'] ?? '') == 'Mobile Wallet' ? 'selected' : '' ?>>Mobile Wallet (Paytm, etc.)</option>
              <option value="Online Transfer" <?= ($_POST['payment_method'] ?? '') == 'Online Transfer' ? 'selected' : '' ?>>Online Bank Transfer</option>
            </optgroup>
            <optgroup label="Cards">
              <option value="Credit Card" <?= ($_POST['payment_method'] ?? '') == 'Credit Card' ? 'selected' : '' ?>>Credit Card</option>
              <option value="Debit Card" <?= ($_POST['payment_method'] ?? '') == 'Debit Card' ? 'selected' : '' ?>>Debit Card</option>
              <option value="Prepaid Card" <?= ($_POST['payment_method'] ?? '') == 'Prepaid Card' ? 'selected' : '' ?>>Prepaid Card</option>
            </optgroup>
            <optgroup label="Traditional Methods">
              <option value="Cash" <?= ($_POST['payment_method'] ?? '') == 'Cash' ? 'selected' : '' ?>>Cash</option>
              <option value="Cheque" <?= ($_POST['payment_method'] ?? '') == 'Cheque' ? 'selected' : '' ?>>Cheque</option>
              <option value="Bank Draft" <?= ($_POST['payment_method'] ?? '') == 'Bank Draft' ? 'selected' : '' ?>>Bank Draft</option>
            </optgroup>
            <optgroup label="Other Methods">
              <option value="Cryptocurrency" <?= ($_POST['payment_method'] ?? '') == 'Cryptocurrency' ? 'selected' : '' ?>>Cryptocurrency</option>
              <option value="Gift Card" <?= ($_POST['payment_method'] ?? '') == 'Gift Card' ? 'selected' : '' ?>>Gift Card/Voucher</option>
              <option value="Other" <?= ($_POST['payment_method'] ?? '') == 'Other' ? 'selected' : '' ?>>Other</option>
            </optgroup>
          </select>
        </div>

        <!-- Form Actions -->
        <div class="flex flex-col sm:flex-row justify-end gap-3 mt-6">
          <a href="dashboard.php" class="px-6 py-3 rounded-lg border border-blue-200 hover:bg-blue-50 text-blue-700 text-center mobile-tap-target">
            Cancel
          </a>
          <button type="submit" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors mobile-tap-target">
            Add Expense
          </button>
        </div>
      </div>
    </form>
  </div>

  <!-- Floating Action Menu -->
  <div class="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50">
    <div class="flex gap-3 bg-white px-3 py-2 rounded-full shadow-xl border border-blue-100">
      <a href="add-expense.php" class="p-3 bg-blue-600 text-white rounded-full shadow-md mobile-tap-target">
        <span class="material-symbols-rounded">add</span>
      </a>
      <!-- Other buttons -->
    </div>
  </div>

  <script>
  // Unified Profile Dropdown Logic
  document.addEventListener('DOMContentLoaded', () => {
    const trigger = document.getElementById('profileDropdown');
    const menu = document.getElementById('profileMenu');

    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.classList.toggle('opacity-0');
      menu.classList.toggle('invisible');
      menu.classList.toggle('opacity-100');
      menu.classList.toggle('visible');
    });

    document.addEventListener('click', (e) => {
      if (!trigger.contains(e.target)) {
        menu.classList.add('opacity-0', 'invisible');
        menu.classList.remove('opacity-100', 'visible');
      }
    });
  });
  </script>
</body>
</html>