<?php
session_start();
require __DIR__ . '/config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
    $token = $_POST['token'];
    $password = $_POST['password'];

    // Validate token
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE reset_token = ? AND reset_expires > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        
        // Update password and clear reset token
        $stmt = $conn->prepare("UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires = NULL WHERE user_id = ?");
        $stmt->bind_param("si", $passwordHash, $user['user_id']);
        
        if ($stmt->execute()) {
            $success = "Password updated successfully! You can now <a href='login.php'>login</a>";
        } else {
            $error = "Error updating password";
        }
    } else {
        $error = "Invalid or expired reset token";
    }
} else if (isset($_GET['token'])) {
    $token = $_GET['token'];
    // Verify token validity
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE reset_token = ? AND reset_expires > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows !== 1) {
        $error = "Invalid or expired reset token";
    }
} else {
    header("Location: forgot-password.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Same styling as forgot password page -->
</head>
<body class="gradient-bg flex items-center justify-center min-h-screen p-4">
    <div class="w-full max-w-md">
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden transition-all transform hover:shadow-2xl">
            <div class="p-8">
                <div class="flex justify-center mb-6">
                    <div class="bg-blue-100 p-3 rounded-full">
                        <i class="fas fa-key text-blue-600 text-3xl"></i>
                    </div>
                </div>
                <h2 class="text-3xl font-bold text-center text-gray-800 mb-2">Reset Password</h2>
                
                <?php if ($error): ?>
                    <!-- Error message display -->
                <?php endif; ?>

                <?php if ($success): ?>
                    <!-- Success message display -->
                <?php else: ?>
                    <form method="POST">
                        <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                        <div class="mb-4">
                            <label for="password" class="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-lock text-gray-400"></i>
                                </div>
                                <input type="password" id="password" name="password" required
                                       class="pl-10 w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none focus:border-blue-500 transition-all">
                            </div>
                        </div>

                        <button type="submit"
                                class="w-full gradient-bg text-white py-3 px-4 rounded-lg font-medium hover:opacity-90 transition-all flex items-center justify-center">
                            <i class="fas fa-sync-alt mr-2"></i> Reset Password
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>