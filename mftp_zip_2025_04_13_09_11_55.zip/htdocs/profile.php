<?php
session_start();
include __DIR__ . '/config.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}

// Fetch user data
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Currency conversion rates (simplified - in a real app, use an API)
$currency_rates = [
    'USD' => 1.0,
    'EUR' => 0.85,
    'GBP' => 0.73,
    'JPY' => 110.0,
    'INR' => 75.0,
    'CAD' => 1.25
];

// Handle profile updates
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle currency update
    if (isset($_POST['currency'])) {
        $new_currency = $_POST['currency'];
        $update_stmt = $conn->prepare("UPDATE users SET currency = ? WHERE user_id = ?");
        $update_stmt->bind_param("si", $new_currency, $user_id);
        if ($update_stmt->execute()) {
            $_SESSION['currency'] = $new_currency;
            $user['currency'] = $new_currency;
            $success_message = "Currency updated successfully!";
        } else {
            $error_message = "Failed to update currency.";
        }
    }
    
    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['profile_picture']['type'];
        
        if (in_array($file_type, $allowed_types)) {
            $upload_dir = 'uploads/profile_pictures/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_ext = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
            $new_filename = 'user_' . $user_id . '_' . time() . '.' . $file_ext;
            $destination = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $destination)) {
                // Update database with new profile picture path
                $update_pic_stmt = $conn->prepare("UPDATE users SET profile_image = ? WHERE user_id = ?");
                $update_pic_stmt->bind_param("si", $destination, $user_id);
                if ($update_pic_stmt->execute()) {
                    $_SESSION['profile_img'] = $destination;
                    $user['profile_image'] = $destination;
                    $success_message = "Profile picture updated successfully!";
                } else {
                    $error_message = "Failed to update profile picture in database.";
                }
            } else {
                $error_message = "Failed to upload profile picture.";
            }
        } else {
            $error_message = "Invalid file type. Only JPG, PNG, and GIF are allowed.";
        }
    }
    
    // Handle other profile updates (name, email)
    if (isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email'])) {
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $email = trim($_POST['email']);
        
        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = "Invalid email format.";
        } else {
            $update_stmt = $conn->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ? WHERE user_id = ?");
            $update_stmt->bind_param("sssi", $first_name, $last_name, $email, $user_id);
            if ($update_stmt->execute()) {
                $_SESSION['first_name'] = $first_name;
                $_SESSION['last_name'] = $last_name;
                $_SESSION['email'] = $email;
                $user['first_name'] = $first_name;
                $user['last_name'] = $last_name;
                $user['email'] = $email;
                $success_message = $success_message ? $success_message . " Profile information also updated!" : "Profile information updated successfully!";
            } else {
                $error_message = $error_message ? $error_message . " Also failed to update profile information." : "Failed to update profile information.";
            }
        }
    }
}

// Get sample wallet balance (in USD) - in a real app, this would come from your database
$wallet_balance_usd = 1250.00; // Example balance
$current_currency = $user['currency'] ?? 'USD';
$converted_balance = $wallet_balance_usd * $currency_rates[$current_currency];

// Format the balance based on currency
$currency_symbols = [
    'USD' => '$',
    'EUR' => '€',
    'GBP' => '£',
    'JPY' => '¥',
    'INR' => '₹',
    'CAD' => 'C$'
];

$formatted_balance = $currency_symbols[$current_currency] . number_format($converted_balance, 2);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Profile - SpendWise</title>
  <meta name="theme-color" content="#0c4a6e">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
  <style>
    .gradient-bg {
      background: linear-gradient(135deg, #075985 0%, #0c4a6e 100%);
    }
    .input-focus:focus {
      box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.3);
    }
    .transition-all {
      transition: all 0.3s ease;
    }
    .profile-card {
      transform: translateY(0);
      transition: transform 0.3s ease;
    }
    .profile-card:hover {
      transform: translateY(-5px);
    }
    .profile-pic {
      transition: all 0.3s ease;
    }
    .profile-pic:hover {
      transform: scale(1.05);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    }
    .btn-hover:hover {
      transform: translateY(-2px);
    }
    .notification {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 1000;
      animation: slideIn 0.5s forwards, fadeOut 0.5s forwards 3s;
    }
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
  </style>
</head>
<body class="gradient-bg min-h-screen p-4 md:p-8">
  <!-- Notification -->
  <?php if (!empty($success_message)): ?>
    <div class="notification">
      <div class="bg-green-50 border-l-4 border-green-500 p-4 rounded shadow-lg">
        <div class="flex">
          <div class="flex-shrink-0">
            <i class="fas fa-check-circle text-green-500"></i>
          </div>
          <div class="ml-3">
            <p class="text-sm text-green-700"><?= htmlspecialchars($success_message) ?></p>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if (!empty($error_message)): ?>
    <div class="notification">
      <div class="bg-red-50 border-l-4 border-red-500 p-4 rounded shadow-lg">
        <div class="flex">
          <div class="flex-shrink-0">
            <i class="fas fa-exclamation-circle text-red-500"></i>
          </div>
          <div class="ml-3">
            <p class="text-sm text-red-700"><?= htmlspecialchars($error_message) ?></p>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <div class="max-w-4xl mx-auto">
    <!-- Header -->
    <header class="flex justify-between items-center mb-8 animate__animated animate__fadeInDown">
      <div class="flex items-center">
        <a href="dashboard.php" class="bg-blue-100 p-2 rounded-full mr-3 transition-all hover:bg-blue-200">
          <i class="fas fa-arrow-left text-blue-600 text-xl"></i>
        </a>
        <h1 class="text-2xl font-bold text-white">Profile Settings</h1>
      </div>
      <a href="?logout=true" class="flex items-center text-white hover:text-blue-200 transition-all">
        <i class="fas fa-sign-out-alt mr-2"></i> Logout
      </a>
    </header>

    <!-- Main Content -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 animate__animated animate__fadeIn">
      <!-- Profile Card -->
      <div class="md:col-span-1">
        <div class="bg-white rounded-2xl shadow-xl p-6 profile-card h-full">
          <div class="flex flex-col items-center">
            <!-- Profile Picture with Upload Form -->
            <form id="profile_pic_form" method="POST" enctype="multipart/form-data" class="w-full">
              <div class="relative mb-4 profile-pic w-32 h-32 mx-auto">
                <?php if (!empty($user['profile_image'])): ?>
                  <img src="<?= htmlspecialchars($user['profile_image']) ?>" alt="Profile" 
                       class="w-full h-full rounded-full object-cover border-4 border-blue-100" id="profile_img_preview">
                <?php else: ?>
                  <div class="w-full h-full rounded-full bg-blue-100 flex items-center justify-center border-4 border-blue-200" id="profile_img_preview">
                    <i class="fas fa-user text-blue-500 text-4xl"></i>
                  </div>
                <?php endif; ?>
                <input type="file" id="profile_picture" name="profile_picture" accept="image/*" 
                       class="hidden" onchange="previewImage(this)">
                <label for="profile_picture" class="absolute bottom-0 right-0 bg-blue-500 text-white p-2 rounded-full hover:bg-blue-600 transition-all cursor-pointer">
                  <i class="fas fa-pencil-alt text-sm"></i>
                </label>
              </div>
            </form>
            
            <!-- User Info -->
            <h2 class="text-xl font-bold text-gray-800 mb-1">
              <?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?>
            </h2>
            <p class="text-gray-600 mb-4"><?= htmlspecialchars($user['email']) ?></p>
            
            <!-- Wallet Balance -->
            <div class="bg-blue-50 rounded-lg p-3 w-full text-center mb-4">
              <p class="text-sm text-gray-600">Wallet Balance</p>
              <p class="font-bold text-blue-600 text-xl" id="wallet_balance_display">
                <?= $formatted_balance ?>
              </p>
              <p class="text-xs text-gray-500 mt-1">≈ $<?= number_format($wallet_balance_usd, 2) ?> USD</p>
            </div>
            
            <!-- Member Since -->
            <div class="bg-blue-50 rounded-lg p-3 w-full text-center">
              <p class="text-sm text-gray-600">Member since</p>
              <p class="font-medium text-blue-600">
                <?= date('F j, Y', strtotime($user['created_at'])) ?>
              </p>
            </div>
          </div>
        </div>
      </div>

      <!-- Settings Card -->
      <div class="md:col-span-2">
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden animate__animated animate__fadeIn animate__delay-1s">
          <!-- Tabs -->
          <div class="border-b border-gray-200">
            <nav class="flex -mb-px">
              <button type="button" id="account_tab" class="w-1/2 py-4 px-1 text-center border-b-2 font-medium text-sm border-blue-500 text-blue-600">
                <i class="fas fa-cog mr-2"></i> Account Settings
              </button>
              <button type="button" id="notifications_tab" class="w-1/2 py-4 px-1 text-center border-b-2 font-medium text-sm border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300">
                <i class="fas fa-bell mr-2"></i> Notifications
              </button>
            </nav>
          </div>

          <!-- Settings Form -->
          <div class="p-6">
            <form method="POST" enctype="multipart/form-data" id="profile_form">
              <div id="account_settings">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <!-- First Name -->
                  <div>
                    <label for="first_name" class="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                    <div class="relative">
                      <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <i class="fas fa-user text-gray-400"></i>
                      </div>
                      <input type="text" id="first_name" name="first_name" value="<?= htmlspecialchars($user['first_name']) ?>"
                            class="pl-10 w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none focus:border-blue-500 transition-all">
                    </div>
                  </div>

                  <!-- Last Name -->
                  <div>
                    <label for="last_name" class="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                    <div class="relative">
                      <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <i class="fas fa-user text-gray-400"></i>
                      </div>
                      <input type="text" id="last_name" name="last_name" value="<?= htmlspecialchars($user['last_name']) ?>"
                            class="pl-10 w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none focus:border-blue-500 transition-all">
                    </div>
                  </div>
                </div>

                <!-- Email -->
                <div class="mb-6">
                  <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <i class="fas fa-envelope text-gray-400"></i>
                    </div>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>"
                          class="pl-10 w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none focus:border-blue-500 transition-all">
                  </div>
                </div>

                <!-- Currency -->
                <div class="mb-8">
                  <label for="currency" class="block text-sm font-medium text-gray-700 mb-1">Currency</label>
                  <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <i class="fas fa-money-bill-wave text-gray-400"></i>
                    </div>
                    <select id="currency" name="currency" class="pl-10 w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none focus:border-blue-500 transition-all appearance-none">
                      <option value="USD" <?= $user['currency'] === 'USD' ? 'selected' : '' ?>>US Dollar (USD)</option>
                      <option value="EUR" <?= $user['currency'] === 'EUR' ? 'selected' : '' ?>>Euro (EUR)</option>
                      <option value="GBP" <?= $user['currency'] === 'GBP' ? 'selected' : '' ?>>British Pound (GBP)</option>
                      <option value="JPY" <?= $user['currency'] === 'JPY' ? 'selected' : '' ?>>Japanese Yen (JPY)</option>
                      <option value="INR" <?= $user['currency'] === 'INR' ? 'selected' : '' ?>>Indian Rupee (INR)</option>
                      <option value="CAD" <?= $user['currency'] === 'CAD' ? 'selected' : '' ?>>Canadian Dollar (CAD)</option>
                    </select>
                    <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                  </div>
                </div>

                <!-- Buttons -->
                <div class="flex flex-col sm:flex-row justify-end gap-3">
                  <button type="button" onclick="window.location.href='dashboard.php'" class="px-6 py-3 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-all btn-hover">
                    Cancel
                  </button>
                  <button type="submit" class="gradient-bg text-white py-3 px-6 rounded-lg font-medium hover:opacity-90 transition-all flex items-center justify-center btn-hover">
                    <i class="fas fa-save mr-2"></i> Save Changes
                  </button>
                </div>
              </div>

              <!-- Notifications Tab Content (hidden by default) -->
              <div id="notifications_settings" class="hidden">
                <div class="mb-6">
                  <h3 class="text-lg font-medium text-gray-800 mb-4">Notification Preferences</h3>
                  
                  <div class="space-y-4">
                    <div class="flex items-center justify-between">
                      <div>
                        <h4 class="text-sm font-medium text-gray-700">Email Notifications</h4>
                        <p class="text-sm text-gray-500">Receive important updates via email</p>
                      </div>
                      <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" class="sr-only peer" checked>
                        <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                    </div>
                    
                    <div class="flex items-center justify-between">
                      <div>
                        <h4 class="text-sm font-medium text-gray-700">Expense Alerts</h4>
                        <p class="text-sm text-gray-500">Get notified when you exceed budgets</p>
                      </div>
                      <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" class="sr-only peer" checked>
                        <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                    </div>
                    
                    <div class="flex items-center justify-between">
                      <div>
                        <h4 class="text-sm font-medium text-gray-700">Monthly Reports</h4>
                        <p class="text-sm text-gray-500">Receive monthly spending summaries</p>
                      </div>
                      <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" class="sr-only peer">
                        <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                    </div>
                  </div>
                </div>
                
                <div class="flex justify-end">
                  <button type="button" class="gradient-bg text-white py-3 px-6 rounded-lg font-medium hover:opacity-90 transition-all flex items-center justify-center btn-hover">
                    <i class="fas fa-save mr-2"></i> Save Preferences
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer class="mt-8 text-center text-white text-sm animate__animated animate__fadeInUp">
      <p>&copy; <?= date('Y') ?> SpendWise. All rights reserved.</p>
    </footer>
  </div>

  <script>
    // Simple animation on load
    document.addEventListener('DOMContentLoaded', function() {
      const elements = document.querySelectorAll('.animate__animated');
      elements.forEach((el, index) => {
        // Add delay based on index for staggered animation
        el.style.animationDelay = `${index * 0.1}s`;
      });
      
      // Add hover effect to buttons
      const buttons = document.querySelectorAll('.btn-hover');
      buttons.forEach(button => {
        button.addEventListener('mouseenter', () => {
          button.classList.add('transform', 'scale-105');
        });
        button.addEventListener('mouseleave', () => {
          button.classList.remove('transform', 'scale-105');
        });
      });

      // Tab switching
      const accountTab = document.getElementById('account_tab');
      const notificationsTab = document.getElementById('notifications_tab');
      const accountSettings = document.getElementById('account_settings');
      const notificationsSettings = document.getElementById('notifications_settings');

      accountTab.addEventListener('click', () => {
        accountTab.classList.add('border-blue-500', 'text-blue-600');
        accountTab.classList.remove('border-transparent', 'text-gray-500');
        notificationsTab.classList.add('border-transparent', 'text-gray-500');
        notificationsTab.classList.remove('border-blue-500', 'text-blue-600');
        accountSettings.classList.remove('hidden');
        notificationsSettings.classList.add('hidden');
      });

      notificationsTab.addEventListener('click', () => {
        notificationsTab.classList.add('border-blue-500', 'text-blue-600');
        notificationsTab.classList.remove('border-transparent', 'text-gray-500');
        accountTab.classList.add('border-transparent', 'text-gray-500');
        accountTab.classList.remove('border-blue-500', 'text-blue-600');
        notificationsSettings.classList.remove('hidden');
        accountSettings.classList.add('hidden');
      });

      // Auto-submit profile picture form when file is selected
      const profilePicForm = document.getElementById('profile_pic_form');
      const profilePicInput = document.getElementById('profile_picture');
      
      profilePicInput.addEventListener('change', function() {
        if (this.files && this.files[0]) {
          profilePicForm.submit();
        }
      });
    });

    // Preview image before upload
    function previewImage(input) {
      if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
          const preview = document.getElementById('profile_img_preview');
          // Check if preview is an image or div
          if (preview.tagName === 'IMG') {
            preview.src = e.target.result;
          } else {
            // Replace div with image
            const img = document.createElement('img');
            img.id = 'profile_img_preview';
            img.src = e.target.result;
            img.className = 'w-full h-full rounded-full object-cover border-4 border-blue-100';
            preview.parentNode.replaceChild(img, preview);
          }
        }
        reader.readAsDataURL(input.files[0]);
      }
    }

    // Currency conversion rates (matches PHP)
    const currencyRates = {
      'USD': 1.0,
      'EUR': 0.85,
      'GBP': 0.73,
      'JPY': 110.0,
      'INR': 75.0,
      'CAD': 1.25
    };

    const currencySymbols = {
      'USD': '$',
      'EUR': '€',
      'GBP': '£',
      'JPY': '¥',
      'INR': '₹',
      'CAD': 'C$'
    };

    // Update wallet balance display when currency changes
    document.getElementById('currency').addEventListener('change', function() {
      const selectedCurrency = this.value;
      const usdBalance = <?= $wallet_balance_usd ?>;
      const convertedBalance = usdBalance * currencyRates[selectedCurrency];
      
      document.getElementById('wallet_balance_display').textContent = 
        currencySymbols[selectedCurrency] + convertedBalance.toFixed(2);
    });
  </script>
</body>
</html>