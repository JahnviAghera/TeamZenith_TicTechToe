<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$transaction = [];
$categories = [];

// Fetch user data
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$user = $user_result->fetch_assoc();
$stmt->close();

// Fetch transaction data
if (isset($_GET['id'])) {
    $transaction_id = $_GET['id'];
    
    $stmt = $conn->prepare("SELECT * FROM transactions 
                          WHERE transaction_id = ? 
                          AND user_id = ?");
    $stmt->bind_param("ii", $transaction_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $transaction = $result->fetch_assoc();
    } else {
        $_SESSION['error'] = "Transaction not found or access denied";
        header("Location: transactions.php");
        exit();
    }
}

// Fetch categories
$stmt = $conn->prepare("SELECT * FROM categories WHERE user_id = ? OR is_default = 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$categories = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $required = ['amount', 'description', 'category_id', 'transaction_type', 'payment_method'];
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("All fields marked with * are required");
            }
        }

        $transaction_id = $_POST['transaction_id'];
        $amount = (float)$_POST['amount'];
        $description = htmlspecialchars($_POST['description']);
        $category_id = (int)$_POST['category_id'];
        $transaction_type = $_POST['transaction_type'];
        $payment_method = $_POST['payment_method'];
        $transaction_date = $_POST['transaction_date'];

        $stmt = $conn->prepare("UPDATE transactions SET
            amount = ?,
            description = ?,
            category_id = ?,
            transaction_type = ?,
            payment_method = ?,
            transaction_date = ?
            WHERE transaction_id = ? AND user_id = ?");

        $stmt->bind_param("dsssssii", 
            $amount,
            $description,
            $category_id,
            $transaction_type,
            $payment_method,
            $transaction_date,
            $transaction_id,
            $user_id
        );

        if ($stmt->execute()) {
            $_SESSION['success'] = "Transaction updated successfully";
            header("Location: transaction.php");
            exit();
        } else {
            throw new Exception("Error updating transaction");
        }

    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Transaction - SpendWise</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0">
  <style>
    .blue-monotone {
      background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
    }
    .progress-bar {
      transition: width 0.5s ease-in-out;
    }
    .input-focus-effect:focus {
      box-shadow: 0 0 0 3px rgba(30, 58, 138, 0.3);
    }
  </style>
</head>
<body class="bg-blue-50 min-h-screen p-4 pb-24">

  <!-- Header -->
  <div class="flex justify-between items-center mb-6">
    <div>
      <h1 class="text-2xl font-bold text-blue-900">Edit Transaction</h1>
      <p class="text-blue-600">Update your transaction details</p>
    </div>
    <!-- Profile Dropdown -->
    <div class="relative group" id="profileDropdown">
      <div class="w-10 h-10 rounded-full bg-blue-100 overflow-hidden flex items-center justify-center cursor-pointer shadow-sm">
        <?php if ($user['profile_image']): ?>
          <img src="<?= htmlspecialchars($user['profile_image']) ?>" class="w-full h-full object-cover">
        <?php else: ?>
          <span class="text-blue-800 font-semibold"><?= strtoupper(substr($user['first_name'], 0, 1)) ?></span>
        <?php endif; ?>
      </div>
      <!-- Dropdown Menu -->
      <div class="absolute right-0 mt-2 w-48 bg-white border border-blue-100 rounded-lg shadow-xl opacity-0 invisible transition-all duration-300 z-50" 
           id="profileMenu">
        <a href="profile.php" class="block px-4 py-3 text-blue-800 hover:bg-blue-50">Profile</a>
        <a href="settings.php" class="block px-4 py-3 text-blue-800 hover:bg-blue-50">Settings</a>
        <form method="POST" action="logout.php">
          <button type="submit" class="w-full text-left px-4 py-3 text-blue-800 hover:bg-blue-50 border-t border-blue-100">
            Logout
          </button>
        </form>
      </div>
    </div>
  </div>

  <!-- Main Form -->
  <div class="max-w-2xl mx-auto">
    <?php if ($error): ?>
      <div class="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
        <span class="material-symbols-rounded text-red-500">error</span>
        <?= $error ?>
      </div>
    <?php endif; ?>

    <form method="POST" class="bg-white p-6 rounded-xl shadow-lg border border-blue-100">
      <input type="hidden" name="transaction_id" value="<?= $transaction['transaction_id'] ?>">
      
      <div class="space-y-4">
        <!-- Description Input -->
        <div>
          <label class="block text-sm font-medium text-blue-700 mb-2">
            Description*
          </label>
          <input type="text" name="description" required 
                class="w-full px-4 py-2.5 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect"
                value="<?= htmlspecialchars($transaction['description'] ?? '') ?>">
        </div>

        <!-- Amount Input -->
        <div>
          <label class="block text-sm font-medium text-blue-700 mb-2">
            Amount*
          </label>
          <input type="number" step="0.01" name="amount" required
                class="w-full px-4 py-2.5 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect"
                value="<?= htmlspecialchars($transaction['amount'] ?? '') ?>">
        </div>

        <!-- Transaction Type -->
        <div>
          <label class="block text-sm font-medium text-blue-700 mb-2">
            Transaction Type*
          </label>
          <select name="transaction_type" required 
                 class="w-full px-4 py-2.5 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect">
            <option value="expense" <?= ($transaction['transaction_type'] ?? '') == 'expense' ? 'selected' : '' ?>>Expense</option>
            <option value="income" <?= ($transaction['transaction_type'] ?? '') == 'income' ? 'selected' : '' ?>>Income</option>
          </select>
        </div>

        <!-- Category Selector -->
        <div class="relative">
          <label class="block text-sm font-medium text-blue-700 mb-2">
            Category*
          </label>
          <div class="relative">
            <select name="category_id" required 
                   class="w-full px-4 py-2.5 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect">
              <option value="">Select Category</option>
              <?php foreach ($categories as $category): ?>
                <option value="<?= $category['category_id'] ?>" <?= ($transaction['category_id'] ?? '') == $category['category_id'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($category['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <!-- Payment Method -->
        <div>
          <label class="block text-sm font-medium text-blue-700 mb-2">
            Payment Method*
          </label>
          <select name="payment_method" required 
                 class="w-full px-4 py-2.5 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect">
            <option value="" disabled>Select payment method</option>
            <optgroup label="Digital Payments">
              <option value="UPI" <?= ($transaction['payment_method'] ?? '') == 'UPI' ? 'selected' : '' ?>>UPI (PhonePe, GPay, etc.)</option>
              <option value="Net Banking" <?= ($transaction['payment_method'] ?? '') == 'Net Banking' ? 'selected' : '' ?>>Net Banking</option>
              <option value="Mobile Wallet" <?= ($transaction['payment_method'] ?? '') == 'Mobile Wallet' ? 'selected' : '' ?>>Mobile Wallet (Paytm, etc.)</option>
              <option value="Online Transfer" <?= ($transaction['payment_method'] ?? '') == 'Online Transfer' ? 'selected' : '' ?>>Online Bank Transfer</option>
            </optgroup>
            <optgroup label="Cards">
              <option value="Credit Card" <?= ($transaction['payment_method'] ?? '') == 'Credit Card' ? 'selected' : '' ?>>Credit Card</option>
              <option value="Debit Card" <?= ($transaction['payment_method'] ?? '') == 'Debit Card' ? 'selected' : '' ?>>Debit Card</option>
              <option value="Prepaid Card" <?= ($transaction['payment_method'] ?? '') == 'Prepaid Card' ? 'selected' : '' ?>>Prepaid Card</option>
            </optgroup>
            <optgroup label="Traditional Methods">
              <option value="Cash" <?= ($transaction['payment_method'] ?? '') == 'Cash' ? 'selected' : '' ?>>Cash</option>
              <option value="Cheque" <?= ($transaction['payment_method'] ?? '') == 'Cheque' ? 'selected' : '' ?>>Cheque</option>
              <option value="Bank Draft" <?= ($transaction['payment_method'] ?? '') == 'Bank Draft' ? 'selected' : '' ?>>Bank Draft</option>
            </optgroup>
            <optgroup label="Other Methods">
              <option value="Cryptocurrency" <?= ($transaction['payment_method'] ?? '') == 'Cryptocurrency' ? 'selected' : '' ?>>Cryptocurrency</option>
              <option value="Gift Card" <?= ($transaction['payment_method'] ?? '') == 'Gift Card' ? 'selected' : '' ?>>Gift Card/Voucher</option>
              <option value="Other" <?= ($transaction['payment_method'] ?? '') == 'Other' ? 'selected' : '' ?>>Other</option>
            </optgroup>
          </select>
        </div>

        <!-- Transaction Date -->
        <div>
          <label class="block text-sm font-medium text-blue-700 mb-2">
            Transaction Date*
          </label>
          <input type="date" name="transaction_date" required
                 class="w-full px-4 py-2.5 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect"
                 value="<?= htmlspecialchars($transaction['transaction_date'] ?? date('Y-m-d')) ?>">
        </div>
      </div>

      <!-- Form Actions -->
      <div class="flex justify-end gap-3 mt-6">
        <a href="transactions.php" class="px-6 py-2.5 rounded-lg border border-blue-200 hover:bg-blue-50 text-blue-700">
          Cancel
        </a>
        <button type="submit" class="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          Update Transaction
        </button>
      </div>
    </form>
  </div>

  <!-- Floating Action Menu -->
  <div class="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50">
    <div class="flex gap-3 bg-white px-3 py-2 rounded-full shadow-xl border border-blue-100">
      <a href="add-expense.php" class="p-3 bg-blue-600 text-white rounded-full shadow-md">
        <span class="material-symbols-rounded">add</span>
      </a>
      <a href="dashboard.php" class="p-3 text-blue-600 rounded-full hover:bg-blue-50">
        <span class="material-symbols-rounded">home</span>
      </a>
      <a href="transactions.php" class="p-3 text-blue-600 rounded-full hover:bg-blue-50">
        <span class="material-symbols-rounded">receipt</span>
      </a>
      <a href="reports.php" class="p-3 text-blue-600 rounded-full hover:bg-blue-50">
        <span class="material-symbols-rounded">bar_chart</span>
      </a>
    </div>
  </div>

  <script>
  // Unified Profile Dropdown Logic
  document.addEventListener('DOMContentLoaded', () => {
    const trigger = document.getElementById('profileDropdown');
    const menu = document.getElementById('profileMenu');

    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.classList.toggle('opacity-0');
      menu.classList.toggle('invisible');
      menu.classList.toggle('opacity-100');
      menu.classList.toggle('visible');
    });

    document.addEventListener('click', (e) => {
      if (!trigger.contains(e.target)) {
        menu.classList.add('opacity-0', 'invisible');
        menu.classList.remove('opacity-100', 'visible');
      }
    });
  });
  </script>
</body>
</html>