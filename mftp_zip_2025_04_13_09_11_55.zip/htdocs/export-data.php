<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection and data fetching
$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Get user details
$user_stmt = $conn->prepare("SELECT first_name, last_name, email FROM users WHERE user_id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// Get available categories for filters
$categories = [];
$stmt = $conn->prepare("SELECT * FROM categories WHERE user_id = ? OR is_default = 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $categories[] = $row;
}

// Get financial summary
$summary_stmt = $conn->prepare("
    SELECT 
        SUM(CASE WHEN transaction_type = 'income' THEN amount ELSE 0 END) AS total_income,
        SUM(CASE WHEN transaction_type = 'expense' THEN amount ELSE 0 END) AS total_expenses
    FROM transactions 
    WHERE user_id = ?
");
$summary_stmt->bind_param("i", $user_id);
$summary_stmt->execute();
$summary_result = $summary_stmt->get_result();
$summary = $summary_result->fetch_assoc();
$amount_left = $summary['total_income'] - $summary['total_expenses'];

// Process export request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $filters = [
            'start_date' => $_POST['start_date'] ?? '',
            'end_date' => $_POST['end_date'] ?? '',
            'transaction_type' => $_POST['transaction_type'] ?? 'all',
            'category_id' => $_POST['category_id'] ?? 'all',
            'format' => $_POST['format'] ?? 'csv'
        ];

        // Build base query
        $query = "SELECT t.transaction_date, t.description, t.amount, t.transaction_type, c.name AS category_name 
                 FROM transactions t
                 LEFT JOIN categories c ON t.category_id = c.category_id
                 WHERE t.user_id = ?";
        $params = [$user_id];
        $types = 'i';

        // Add date filters
        if (!empty($filters['start_date']) && !empty($filters['end_date'])) {
            $query .= " AND t.transaction_date BETWEEN ? AND ?";
            $params[] = $filters['start_date'];
            $params[] = $filters['end_date'];
            $types .= 'ss';
        }

        // Add transaction type filter
        if ($filters['transaction_type'] !== 'all') {
            $query .= " AND t.transaction_type = ?";
            $params[] = $filters['transaction_type'];
            $types .= 's';
        }

        // Add category filter
        if ($filters['category_id'] !== 'all') {
            $query .= " AND t.category_id = ?";
            $params[] = $filters['category_id'];
            $types .= 'i';
        }

        $stmt = $conn->prepare($query);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        $transactions = $result->fetch_all(MYSQLI_ASSOC);

        if (empty($transactions)) {
            throw new Exception("No transactions found with selected filters");
        }

        // Generate export file
        switch ($filters['format']) {
            case 'csv':
                exportCSV($transactions, $user, $summary, $amount_left);
                break;
            case 'pdf':
                exportPDF($transactions, $user, $summary, $amount_left);
                break;
            default:
                throw new Exception("Invalid export format");
        }

    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

function exportCSV($data, $user, $summary, $amount_left) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="spendwise_export_'.date('Ymd').'.csv"');
    
    $output = fopen('php://output', 'w');
    
    // User information header
    fputcsv($output, ['SpendWise Transaction Report']);
    fputcsv($output, ['']);
    fputcsv($output, ['User:', $user['first_name'].' '.$user['last_name']]);
    fputcsv($output, ['Email:', $user['email']]);
    fputcsv($output, ['Total Income:', number_format($summary['total_income'], 2)]);
    fputcsv($output, ['Total Expenses:', number_format($summary['total_expenses'], 2)]);
    fputcsv($output, ['Amount Left:', number_format($amount_left, 2)]);
    fputcsv($output, ['']);
    fputcsv($output, ['Transaction Details']);
    fputcsv($output, ['']);
    
    // Header row
    fputcsv($output, array_keys($data[0]));
    
    // Data rows
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit();
}

function exportPDF($data, $user, $summary, $amount_left) {
    require_once('fpdf/fpdf.php');
    
    $pdf = new FPDF();
    $pdf->AddPage();
    
    // Set theme colors
    $primaryColor = array(14, 165, 233);   // 500: #0ea5e9
    $darkColor = array(2, 132, 199);       // 600: #0284c7
    $lightColor = array(224, 242, 254);    // 100: #e0f2fe
    $successColor = array(0, 128, 0);      // Green
    $dangerColor = array(255, 0, 0);       // Red
    $infoColor = array(2, 132, 199);       // 600: #0284c7
    
    // Add logo (replace with your actual logo path)
    if (file_exists('images/logo.png')) {
        $pdf->Image('images/logo.png', 10, 10, 30);
    }
    
    // Header with primary color
    $pdf->SetFont('Arial','B',16);
    $pdf->SetTextColor($primaryColor[0], $primaryColor[1], $primaryColor[2]);
    $pdf->Cell(0,10,'SpendWise Transaction Report',0,1,'C');
    $pdf->SetTextColor(0); // Reset to black
    $pdf->Ln(10);
    
    // User Information Section with light background
    $pdf->SetFillColor($lightColor[0], $lightColor[1], $lightColor[2]);
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(0,7,'User Information',1,1,'L',true);
    $pdf->SetFont('Arial','',12);
    
    $pdf->Cell(40,7,'Name:',0,0);
    $pdf->Cell(0,7,$user['first_name'].' '.$user['last_name'],0,1);
    
    $pdf->Cell(40,7,'Email:',0,0);
    $pdf->Cell(0,7,$user['email'],0,1);
    $pdf->Ln(5);
    
    // Financial Summary Section
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(0,7,'Financial Summary',1,1,'L',true);
    $pdf->SetFont('Arial','',12);
    
    // Income Row
    $pdf->Cell(40,7,'Total Income:',0,0);
    $pdf->SetTextColor($successColor[0], $successColor[1], $successColor[2]);
    $pdf->Cell(0,7,'Rs. ' . number_format($summary['total_income'], 2),0,1);
    $pdf->SetTextColor(0); // Reset to black
    
    // Expenses Row
    $pdf->Cell(40,7,'Total Expenses:',0,0);
    $pdf->SetTextColor($dangerColor[0], $dangerColor[1], $dangerColor[2]);
    $pdf->Cell(0,7,'Rs. ' . number_format($summary['total_expenses'], 2),0,1);
    $pdf->SetTextColor(0); // Reset to black
    
    // Amount Left Row
    $pdf->Cell(40,7,'Amount Left:',0,0);
    $pdf->SetTextColor($darkColor[0], $darkColor[1], $darkColor[2]);
    $pdf->Cell(0,7,'Rs. ' . number_format($amount_left, 2),0,1);
    $pdf->SetTextColor(0); // Reset to black
    
    $pdf->Ln(10);
    
    // Transaction Details Header
    $pdf->SetFont('Arial','B',12);
    $pdf->SetFillColor($primaryColor[0], $primaryColor[1], $primaryColor[2]);
    $pdf->SetTextColor(255,255,255); // White text
    $pdf->Cell(0,7,'Transaction Details',1,1,'C',true);
    $pdf->SetTextColor(0); // Reset to black
    $pdf->Ln(5);
    
    // Table Header
    $pdf->SetFont('Arial','B',10);
    $pdf->SetFillColor($lightColor[0], $lightColor[1], $lightColor[2]);
    $pdf->Cell(25,7,'Date',1,0,'C',true);
    $pdf->Cell(65,7,'Description',1,0,'C',true);
    $pdf->Cell(30,7,'Amount',1,0,'C',true);
    $pdf->Cell(30,7,'Type',1,0,'C',true);
    $pdf->Cell(30,7,'Category',1,1,'C',true);
    
    // Table Data
    $pdf->SetFont('Arial','',10);
    $fill = false;
    foreach ($data as $row) {
        $pdf->SetFillColor($fill ? 240 : 255); // Alternate row colors
        
        // Date
        $pdf->Cell(25,6,$row['transaction_date'],1,0,'',$fill);
        
        // Description
        $pdf->Cell(65,6,$row['description'],1,0,'',$fill);
        
        // Amount with proper formatting and color
        $amount = 'Rs. ' . number_format(abs($row['amount']), 2);
        if ($row['amount'] < 0) {
            $amount = '-Rs. ' . number_format(abs($row['amount']), 2);
        }
        
        if ($row['transaction_type'] === 'income') {
            $pdf->SetTextColor($successColor[0], $successColor[1], $successColor[2]);
        } else {
            $pdf->SetTextColor($dangerColor[0], $dangerColor[1], $dangerColor[2]);
        }
        $pdf->Cell(30,6,$amount,1,0,'R',$fill);
        $pdf->SetTextColor(0); // Reset to black
        
        // Type and Category
        $pdf->Cell(30,6,ucfirst($row['transaction_type']),1,0,'',$fill);
        $pdf->Cell(30,6,$row['category_name'],1,1,'',$fill);
        
        $fill = !$fill; // Toggle fill
    }
    
    // Footer
    $pdf->SetY(-15);
    $pdf->SetFont('Arial','I',8);
    $pdf->SetTextColor($darkColor[0], $darkColor[1], $darkColor[2]);
    $pdf->Cell(0,10,'Generated on '.date('Y-m-d H:i:s'),0,0,'C');
    
    $pdf->Output('D', 'spendwise_export_'.date('Ymd').'.pdf');
    exit();
}

// Get user data from session
$first_name = $_SESSION['first_name'] ?? 'User';
$profile_img = $_SESSION['profile_img'] ?? null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Export Data - SpendWise</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0">
  <style>
    .blue-monotone {
      background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
    }
    .input-focus:focus {
      box-shadow: 0 0 0 3px rgba(30, 58, 138, 0.3);
    }
    /* Mobile-specific styles */
    @media (max-width: 640px) {
      .mobile-tap-target {
        min-height: 48px;
        padding: 12px 16px;
      }
      .mobile-text-lg {
        font-size: 1.125rem;
      }
      .mobile-stack {
        flex-direction: column;
        gap: 0.5rem;
      }
    }
    .logo {
      height: 40px;
      margin-right: 10px;
    }
  </style>
</head>
<body class="bg-blue-50 min-h-screen p-4 pb-24 md:pb-4">

  <!-- Header -->
  <div class="flex justify-between items-center mb-6">
    <div class="flex items-center">
      <!--<img src="images/logo.png" alt="SpendWise Logo" class="logo">-->
      <div>
        <h1 class="text-2xl font-bold text-blue-900 mobile-text-lg">Export Financial Data</h1>
        <p class="text-blue-600 text-sm md:text-base">Export your transaction history</p>
      </div>
    </div>
    <!-- Profile Dropdown -->
    <div class="relative group" id="profileDropdown">
      <div class="w-10 h-10 rounded-full bg-blue-100 overflow-hidden flex items-center justify-center cursor-pointer shadow-sm">
        <?php if ($profile_img): ?>
          <img src="<?= htmlspecialchars($profile_img) ?>" class="w-full h-full object-cover">
        <?php else: ?>
          <span class="text-blue-800 font-semibold"><?= strtoupper(substr($first_name, 0, 1)) ?></span>
        <?php endif; ?>
      </div>
      <div class="absolute right-0 mt-2 w-48 bg-white border border-blue-100 rounded-lg shadow-xl opacity-0 invisible transition-all duration-300 z-50" id="profileMenu">
        <a href="profile.php" class="block px-4 py-3 text-blue-800 hover:bg-blue-50 mobile-tap-target">Profile</a>
        <a href="settings.php" class="block px-4 py-3 text-blue-800 hover:bg-blue-50 mobile-tap-target">Settings</a>
        <form method="POST" action="logout.php">
          <button type="submit" class="w-full text-left px-4 py-3 text-blue-800 hover:bg-blue-50 border-t border-blue-100 mobile-tap-target">
            Logout
          </button>
        </form>
      </div>
    </div>
  </div>

  <!-- User Summary -->
  <div class="bg-white p-4 rounded-lg shadow mb-6">
    <h2 class="text-lg font-semibold text-blue-800 mb-2">Financial Summary</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div class="bg-blue-50 p-3 rounded-lg">
        <p class="text-sm text-blue-600">User</p>
        <p class="font-medium"><?= htmlspecialchars($user['first_name'].' '.$user['last_name']) ?></p>
      </div>
      <div class="bg-blue-50 p-3 rounded-lg">
        <p class="text-sm text-blue-600">Email</p>
        <p class="font-medium"><?= htmlspecialchars($user['email']) ?></p>
      </div>
      <div class="bg-green-50 p-3 rounded-lg">
        <p class="text-sm text-green-600">Total Income</p>
        <p class="font-medium">₹<?= number_format($summary['total_income'], 2) ?></p>
      </div>
      <div class="bg-red-50 p-3 rounded-lg">
        <p class="text-sm text-red-600">Total Expenses</p>
        <p class="font-medium">₹<?= number_format($summary['total_expenses'], 2) ?></p>
      </div>
      <div class="bg-blue-100 p-3 rounded-lg">
        <p class="text-sm text-blue-800">Amount Left</p>
        <p class="font-medium">₹<?= number_format($amount_left, 2) ?></p>
      </div>
    </div>
  </div>

  <!-- Export Form -->
  <div class="max-w-2xl mx-auto w-full">
    <?php if ($error): ?>
      <div class="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
        <span class="material-symbols-rounded text-red-500">error</span>
        <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <form method="POST" class="bg-white p-4 md:p-6 rounded-xl shadow-lg border border-blue-100">
      <div class="space-y-4">
        <!-- Date Range -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-blue-700 mb-2">Start Date</label>
            <input type="date" name="start_date" 
                   class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus mobile-tap-target">
          </div>
          <div>
            <label class="block text-sm font-medium text-blue-700 mb-2">End Date</label>
            <input type="date" name="end_date" 
                   class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus mobile-tap-target">
          </div>
        </div>

        <!-- Transaction Type -->
        <div>
          <label class="block text-sm font-medium text-blue-700 mb-2">Transaction Type</label>
          <select name="transaction_type" 
                 class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus mobile-tap-target">
            <option value="all">All Transactions</option>
            <option value="income">Income</option>
            <option value="expense">Expenses</option>
          </select>
        </div>

        <!-- Category Filter -->
        <div>
          <label class="block text-sm font-medium text-blue-700 mb-2">Category</label>
          <select name="category_id" 
                 class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus mobile-tap-target">
            <option value="all">All Categories</option>
            <?php foreach ($categories as $category): ?>
              <option value="<?= $category['category_id'] ?>">
                <?= htmlspecialchars($category['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- Export Format -->
        <div>
          <label class="block text-sm font-medium text-blue-700 mb-2">Export Format</label>
          <div class="flex gap-4 mobile-stack">
            <label class="flex items-center">
              <input type="radio" name="format" value="csv" checked 
                     class="form-radio text-blue-600 h-5 w-5">
              <span class="ml-2">CSV</span>
            </label>
            <label class="flex items-center">
              <input type="radio" name="format" value="pdf"
                     class="form-radio text-blue-600 h-5 w-5">
              <span class="ml-2">PDF</span>
            </label>
          </div>
        </div>

        <!-- Form Actions -->
        <div class="flex flex-col sm:flex-row justify-end gap-3 mt-6">
          <a href="dashboard.php" class="px-6 py-3 rounded-lg border border-blue-200 hover:bg-blue-50 text-blue-700 text-center mobile-tap-target">
            Cancel
          </a>
          <button type="submit" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors mobile-tap-target">
            Export Data
          </button>
        </div>
      </div>
    </form>
  </div>

  <!-- Floating Action Menu -->
  <div class="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50">
    <div class="flex gap-3 bg-white px-3 py-2 rounded-full shadow-xl border border-blue-100">
      <a href="add-expense.php" class="p-3 bg-blue-600 text-white rounded-full shadow-md mobile-tap-target">
        <span class="material-symbols-rounded">add</span>
      </a>
    </div>
  </div>

  <script>
  // Profile Dropdown Logic
  document.addEventListener('DOMContentLoaded', () => {
    const trigger = document.getElementById('profileDropdown');
    const menu = document.getElementById('profileMenu');

    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.classList.toggle('opacity-0');
      menu.classList.toggle('invisible');
      menu.classList.toggle('opacity-100');
      menu.classList.toggle('visible');
    });

    document.addEventListener('click', (e) => {
      if (!trigger.contains(e.target)) {
        menu.classList.add('opacity-0', 'invisible');
        menu.classList.remove('opacity-100', 'visible');
      }
    });
  });
  </script>
</body>
</html>