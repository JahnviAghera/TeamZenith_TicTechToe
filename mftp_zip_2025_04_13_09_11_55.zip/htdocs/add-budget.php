<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Fetch categories from database
$category_stmt = $conn->prepare("SELECT * FROM categories WHERE user_id = ? OR is_default = 1");
$category_stmt->bind_param("i", $user_id);
$category_stmt->execute();
$categories = $category_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$category_stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $required = ['amount', 'period', 'start_date', 'category_id'];
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("All fields marked with * are required");
            }
        }

        $amount = (float)$_POST['amount'];
        $period = $_POST['period'];
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'] ?? null;
        $category_id = (int)$_POST['category_id'];

        // Validate category exists
        $valid_category = false;
        foreach ($categories as $cat) {
            if ($cat['category_id'] == $category_id) {
                $valid_category = true;
                break;
            }
        }
        if (!$valid_category) {
            throw new Exception("Invalid category selected");
        }

        $stmt = $conn->prepare("INSERT INTO budgets (user_id, amount, period, start_date, end_date, category_id) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("idsssi", $user_id, $amount, $period, $start_date, $end_date, $category_id);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Budget created successfully!";
            header("Location: dashboard.php");
            exit();
        } else {
            throw new Exception("Error saving budget: " . $conn->error);
        }

    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Budget - SpendWise</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0">
    <style>
        .blue-monotone {
            background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
        }
        .input-focus-effect:focus {
            box-shadow: 0 0 0 3px rgba(30, 58, 138, 0.3);
        }
        .suggestions-container {
            position: absolute;
            width: 100%;
            max-height: 200px;
            overflow-y: auto;
            z-index: 10;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        }
        .suggestion-item:hover {
            background-color: #f3f4f6;
            transform: translateX(5px);
        }
        /* Mobile-specific styles */
        @media (max-width: 640px) {
            .mobile-tap-target {
                min-height: 48px;
                padding: 12px 16px;
            }
            .mobile-text-lg {
                font-size: 1.125rem;
            }
            .mobile-period-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body class="bg-blue-50 min-h-screen p-4 pb-24 md:pb-4">

    <!-- Header -->
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold text-blue-900 mobile-text-lg">Create New Budget</h1>
            <p class="text-blue-600 text-sm md:text-base">Plan your finances wisely</p>
        </div>
        <!-- Profile Dropdown -->
        <div class="relative group" id="profileDropdown">
            <!-- ... (same profile dropdown as expense page) ... -->
        </div>
    </div>

    <!-- Main Form -->
    <div class="max-w-2xl mx-auto w-full">
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
                <span class="material-symbols-rounded text-red-500">error</span>
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="bg-white p-4 md:p-6 rounded-xl shadow-lg border border-blue-100">
            <div class="space-y-4">
                <!-- Category Selector -->
                <div class="relative">
                    <label class="block text-sm font-medium text-blue-700 mb-2">
                        Category*
                    </label>
                    <div class="relative">
                        <select name="category_id" required 
                               class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect mobile-tap-target">
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['category_id'] ?>" 
                                    <?= ($_POST['category_id'] ?? '') == $category['category_id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($category['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Amount Input -->
                <div>
                    <label class="block text-sm font-medium text-blue-700 mb-2">
                        Amount*
                    </label>
                    <input type="number" step="0.01" name="amount" required
                           class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect mobile-tap-target"
                           value="<?= htmlspecialchars($_POST['amount'] ?? '') ?>">
                </div>

                <!-- Period Selector -->
                <div>
                    <label class="block text-sm font-medium text-blue-700 mb-2">
                        Period*
                    </label>
                    <div class="grid grid-cols-4 mobile-period-grid gap-2">
                        <?php foreach (['daily', 'weekly', 'monthly', 'yearly'] as $period): ?>
                            <button type="button" 
                                    data-period="<?= $period ?>" 
                                    class="period-btn px-4 py-3 text-sm rounded-lg border border-blue-200 mobile-tap-target <?= ($period === 'monthly') ? 'bg-blue-600 text-white' : 'hover:bg-blue-50' ?>">
                                <?= ucfirst($period) ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                    <input type="hidden" name="period" id="periodInput" value="monthly">
                </div>

                <!-- Date Inputs -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-blue-700 mb-2">
                            Start Date*
                        </label>
                        <input type="date" name="start_date" required 
                               class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect mobile-tap-target"
                               value="<?= htmlspecialchars($_POST['start_date'] ?? date('Y-m-d')) ?>">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-blue-700 mb-2">
                            End Date (optional)
                        </label>
                        <input type="date" name="end_date" 
                               class="w-full px-4 py-3 rounded-lg border border-blue-200 focus:border-blue-500 input-focus-effect mobile-tap-target"
                               value="<?= htmlspecialchars($_POST['end_date'] ?? '') ?>">
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="flex flex-col sm:flex-row justify-end gap-3 mt-6">
                    <a href="dashboard.php" class="px-6 py-3 rounded-lg border border-blue-200 hover:bg-blue-50 text-blue-700 text-center mobile-tap-target">
                        Cancel
                    </a>
                    <button type="submit" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors mobile-tap-target">
                        Create Budget
                    </button>
                </div>
            </div>
        </form>
    </div>

    <script>
        // Period Selection
        document.querySelectorAll('.period-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.period-btn').forEach(b => {
                    b.classList.remove('bg-blue-600', 'text-white');
                    b.classList.add('hover:bg-blue-50');
                });
                this.classList.add('bg-blue-600', 'text-white');
                this.classList.remove('hover:bg-blue-50');
                document.getElementById('periodInput').value = this.dataset.period;
            });
        });
    </script>
</body>
</html>