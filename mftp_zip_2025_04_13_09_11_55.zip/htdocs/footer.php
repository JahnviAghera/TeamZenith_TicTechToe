<?php
// footer.php
?>

<footer class="bg-gray-900 text-white py-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
                <div class="flex items-center mb-4">
                    <i class="fas fa-wallet text-indigo-400 text-2xl mr-2 animate__animated animate__pulse animate__infinite animate__slower"></i>
                    <span class="text-xl font-bold">Spend<span class="text-green-600">Wise</span></span>
                </div>
                <p class="text-gray-400">Smart personal finance management for everyone.</p>
                <div class="mt-4 flex space-x-4">
                    <a href="#" class="text-gray-400 hover:text-white transition duration-300 tooltip">
                        <i class="fab fa-twitter text-xl"></i>
                        <span class="tooltip-text">Twitter</span>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition duration-300 tooltip">
                        <i class="fab fa-facebook text-xl"></i>
                        <span class="tooltip-text">Facebook</span>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition duration-300 tooltip">
                        <i class="fab fa-instagram text-xl"></i>
                        <span class="tooltip-text">Instagram</span>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition duration-300 tooltip">
                        <i class="fab fa-linkedin text-xl"></i>
                        <span class="tooltip-text">LinkedIn</span>
                    </a>
                </div>
            </div>
            <div>
                <h3 class="text-lg font-bold mb-4">Product</h3>
                <ul class="space-y-2">
                    <li><a href="#features" class="text-gray-400 hover:text-white transition duration-300">Features</a></li>
                    <li><a href="#how-it-works" class="text-gray-400 hover:text-white transition duration-300">How It Works</a></li>
                </ul>
            </div>
            <div>
                <h3 class="text-lg font-bold mb-4">Company</h3>
                <ul class="space-y-2">
                    <li><a href="about.php" class="text-gray-400 hover:text-white transition duration-300">About Us</a></li>
                    <li><a href="careers.php" class="text-gray-400 hover:text-white transition duration-300">Careers</a></li>
                    <li><a href="blog.php" class="text-gray-400 hover:text-white transition duration-300">Blog</a></li>
                    <li><a href="contact.php" class="text-gray-400 hover:text-white transition duration-300">Contact</a></li>
                </ul>
            </div>
            <div>
                <h3 class="text-lg font-bold mb-4">Legal</h3>
                <ul class="space-y-2">
                    <li><a href="privacy.php" class="text-gray-400 hover:text-white transition duration-300">Privacy Policy</a></li>
                    <li><a href="terms.php" class="text-gray-400 hover:text-white transition duration-300">Terms of Service</a></li>
                    <li><a href="security.php" class="text-gray-400 hover:text-white transition duration-300">Security</a></li>
                </ul>
            </div>
        </div>
        <div class="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; <?php echo date('Y'); ?> Wise. All rights reserved.</p>
        </div>
    </div>
</footer>

<?php
// about.php
if (basename($_SERVER['PHP_SELF']) == 'about.php') { ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - SpendWise</title>
    <!-- Include your CSS and JS files here -->
</head>
<body>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold mb-6">About SpendWise</h1>
        <div class="bg-white p-8 rounded-lg shadow-md">
            <p class="mb-4">SpendWise is a smart personal finance management tool designed to help individuals take control of their financial lives.</p>
            <p class="mb-4">Founded in 2023, our mission is to make financial management accessible and straightforward for everyone, regardless of their financial knowledge.</p>
            <p>Our team of financial experts and developers work tirelessly to create tools that help you track expenses, save money, and achieve your financial goals.</p>
        </div>
    </div>
</body>
</html>
<?php } ?>

<?php
// careers.php
if (basename($_SERVER['PHP_SELF']) == 'careers.php') { ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Careers - SpendWise</title>
    <!-- Include your CSS and JS files here -->
</head>
<body>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold mb-6">Join Our Team</h1>
        <div class="bg-white p-8 rounded-lg shadow-md">
            <p class="mb-6">At SpendWise, we're always looking for talented individuals to join our growing team.</p>
            
            <h2 class="text-xl font-bold mb-4">Current Openings</h2>
            <div class="space-y-4">
                <div class="border-b pb-4">
                    <h3 class="font-semibold">Frontend Developer</h3>
                    <p>Help us build beautiful, responsive interfaces for our financial tools.</p>
                </div>
                <div class="border-b pb-4">
                    <h3 class="font-semibold">Financial Analyst</h3>
                    <p>Work on our budgeting algorithms and financial recommendations.</p>
                </div>
                <div>
                    <h3 class="font-semibold">Customer Support Specialist</h3>
                    <p>Help our users get the most out of SpendWise.</p>
                </div>
            </div>
            
            <p class="mt-8">To apply, please send your resume to careers@spendwise.com</p>
        </div>
    </div>
</body>
</html>
<?php } ?>

<?php
// blog.php
if (basename($_SERVER['PHP_SELF']) == 'blog.php') { ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog - SpendWise</title>
    <!-- Include your CSS and JS files here -->
</head>
<body>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold mb-6">SpendWise Blog</h1>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-bold mb-3">5 Tips for Better Budgeting</h2>
                <p class="text-gray-600 mb-4">Learn how to create a budget that actually works for your lifestyle.</p>
                <a href="#" class="text-blue-600 hover:underline">Read more</a>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-bold mb-3">Saving for Your First Home</h2>
                <p class="text-gray-600 mb-4">Strategies to help you save for a down payment faster.</p>
                <a href="#" class="text-blue-600 hover:underline">Read more</a>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-bold mb-3">Understanding Credit Scores</h2>
                <p class="text-gray-600 mb-4">Everything you need to know about improving your credit.</p>
                <a href="#" class="text-blue-600 hover:underline">Read more</a>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-bold mb-3">Investing for Beginners</h2>
                <p class="text-gray-600 mb-4">A simple guide to getting started with investing.</p>
                <a href="#" class="text-blue-600 hover:underline">Read more</a>
            </div>
        </div>
    </div>
</body>
</html>
<?php } ?>

<?php
// contact.php
if (basename($_SERVER['PHP_SELF']) == 'contact.php') { ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - SpendWise</title>
    <!-- Include your CSS and JS files here -->
</head>
<body>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold mb-6">Contact Our Team</h1>
        <div class="bg-white p-8 rounded-lg shadow-md">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="text-center">
                    <div class="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-user text-blue-600 text-3xl"></i>
                    </div>
                    <h3 class="font-bold text-lg">Payal Makwana</h3>
                    <p class="text-gray-600">9054293225</p>
                    <p class="text-gray-600">iampayal018@gmail.com</p>
                </div>
                <div class="text-center">
                    <div class="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-user text-green-600 text-3xl"></i>
                    </div>
                    <h3 class="font-bold text-lg">Jahnvi Aghera</h3>
                    <p class="text-gray-600">+91 87994 48954</p>
                    <p class="text-gray-600">agherajahnvi@gmail.com</p>
                </div>
                <div class="text-center">
                    <div class="w-24 h-24 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-user text-purple-600 text-3xl"></i>
                    </div>
                    <h3 class="font-bold text-lg">Aditya Raj</h3>
                    <p class="text-gray-600">+91 89693 57069</p>
                    <p class="text-gray-600">adivid198969@gmail.com</p>
                </div>
            </div>
            
            <div class="mt-12">
                <h2 class="text-xl font-bold mb-4">Send us a message</h2>
                <form class="space-y-4">
                    <div>
                        <label for="name" class="block mb-1">Name</label>
                        <input type="text" id="name" class="w-full px-4 py-2 border rounded-lg">
                    </div>
                    <div>
                        <label for="email" class="block mb-1">Email</label>
                        <input type="email" id="email" class="w-full px-4 py-2 border rounded-lg">
                    </div>
                    <div>
                        <label for="message" class="block mb-1">Message</label>
                        <textarea id="message" rows="4" class="w-full px-4 py-2 border rounded-lg"></textarea>
                    </div>
                    <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition duration-300">
                        Send Message
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
<?php } ?>

<?php
// privacy.php
if (basename($_SERVER['PHP_SELF']) == 'privacy.php') { ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - SpendWise</title>
    <!-- Include your CSS and JS files here -->
</head>
<body>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold mb-6">Privacy Policy</h1>
        <div class="bg-white p-8 rounded-lg shadow-md">
            <p class="mb-4">Last updated: <?php echo date('F j, Y'); ?></p>
            
            <h2 class="text-xl font-bold mt-6 mb-3">1. Information We Collect</h2>
            <p class="mb-4">We collect information you provide directly to us, such as when you create an account, add financial information, or contact us for support.</p>
            
            <h2 class="text-xl font-bold mt-6 mb-3">2. How We Use Your Information</h2>
            <p class="mb-4">We use the information we collect to provide, maintain, and improve our services, to develop new features, and to protect SpendWise and our users.</p>
            
            <h2 class="text-xl font-bold mt-6 mb-3">3. Information Sharing</h2>
            <p class="mb-4">We do not share your personal information with companies, organizations, or individuals outside of SpendWise except in specific cases outlined in this policy.</p>
            
            <h2 class="text-xl font-bold mt-6 mb-3">4. Security</h2>
            <p class="mb-4">We work hard to protect your information from unauthorized access, alteration, disclosure, or destruction.</p>
            
            <h2 class="text-xl font-bold mt-6 mb-3">5. Changes to This Policy</h2>
            <p>We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy on this page.</p>
        </div>
    </div>
</body>
</html>
<?php } ?>

<?php
// terms.php
if (basename($_SERVER['PHP_SELF']) == 'terms.php') { ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms of Service - SpendWise</title>
    <!-- Include your CSS and JS files here -->
</head>
<body>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold mb-6">Terms of Service</h1>
        <div class="bg-white p-8 rounded-lg shadow-md">
            <p class="mb-4">Last updated: <?php echo date('F j, Y'); ?></p>
            
            <h2 class="text-xl font-bold mt-6 mb-3">1. Acceptance of Terms</h2>
            <p class="mb-4">By accessing or using the SpendWise service, you agree to be bound by these Terms of Service.</p>
            
            <h2 class="text-xl font-bold mt-6 mb-3">2. Description of Service</h2>
            <p class="mb-4">SpendWise provides personal finance management tools including expense tracking, budgeting, and financial reporting.</p>
            
            <h2 class="text-xl font-bold mt-6 mb-3">3. User Responsibilities</h2>
            <p class="mb-4">You are responsible for maintaining the confidentiality of your account and password and for restricting access to your devices.</p>
            
            <h2 class="text-xl font-bold mt-6 mb-3">4. Privacy</h2>
            <p class="mb-4">Your use of the Service is subject to SpendWise's Privacy Policy, which governs our collection and use of your information.</p>
            
            <h2 class="text-xl font-bold mt-6 mb-3">5. Modifications to Service</h2>
            <p>SpendWise reserves the right at any time to modify or discontinue, temporarily or permanently, the Service with or without notice.</p>
        </div>
    </div>
</body>
</html>
<?php } ?>

<?php
// security.php
if (basename($_SERVER['PHP_SELF']) == 'security.php') { ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security - SpendWise</title>
    <!-- Include your CSS and JS files here -->
</head>
<body>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold mb-6">Security at SpendWise</h1>
        <div class="bg-white p-8 rounded-lg shadow-md">
            <h2 class="text-xl font-bold mb-4">How We Protect Your Data</h2>
            
            <div class="space-y-6">
                <div>
                    <h3 class="font-bold text-lg mb-2">Bank-Level Encryption</h3>
                    <p class="text-gray-700">All your data is encrypted with 256-bit SSL encryption, the same standard used by banks.</p>
                </div>
                
                <div>
                    <h3 class="font-bold text-lg mb-2">Secure Servers</h3>
                    <p class="text-gray-700">Our servers are hosted in secure data centers with multiple layers of physical and digital security.</p>
                </div>
                
                <div>
                    <h3 class="font-bold text-lg mb-2">Two-Factor Authentication</h3>
                    <p class="text-gray-700">Optional two-factor authentication adds an extra layer of security to your account.</p>
                </div>
                
                <div>
                    <h3 class="font-bold text-lg mb-2">Regular Audits</h3>
                    <p class="text-gray-700">We conduct regular security audits to identify and address potential vulnerabilities.</p>
                </div>
                
                <div>
                    <h3 class="font-bold text-lg mb-2">Read-Only Access</h3>
                    <p class="text-gray-700">When you connect your bank accounts, we use read-only access so no changes can be made.</p>
                </div>
            </div>
            
            <div class="mt-8 bg-blue-50 p-4 rounded-lg">
                <h3 class="font-bold text-lg mb-2">Security Tips for Users</h3>
                <ul class="list-disc pl-5 space-y-2">
                    <li>Use a strong, unique password for your SpendWise account</li>
                    <li>Enable two-factor authentication in your account settings</li>
                    <li>Never share your login credentials with anyone</li>
                    <li>Log out of your account when using shared devices</li>
                    <li>Be cautious of phishing attempts - we'll never ask for your password via email</li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>
<?php } ?>