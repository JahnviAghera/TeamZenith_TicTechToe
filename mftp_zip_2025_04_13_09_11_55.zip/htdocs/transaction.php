<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$transactions = [];
$totalPages = 1;
$currentPage = 1;

// Filter parameters
$typeFilter = $_GET['type'] ?? 'all';
$categoryFilter = $_GET['category'] ?? 'all';
$searchQuery = $_GET['search'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$currentPage = max(1, intval($_GET['page'] ?? 1));
$itemsPerPage = 15;

try {
    // Base query
    $query = "SELECT SQL_CALC_FOUND_ROWS t.*, c.name AS category_name, c.color 
             FROM transactions t
             LEFT JOIN categories c ON t.category_id = c.category_id
             WHERE t.user_id = ?";
    
    $params = [$user_id];
    $types = 'i';

    // Add filters
    if ($typeFilter !== 'all') {
        $query .= " AND t.transaction_type = ?";
        $params[] = $typeFilter;
        $types .= 's';
    }

    if ($categoryFilter !== 'all') {
        $query .= " AND t.category_id = ?";
        $params[] = $categoryFilter;
        $types .= 'i';
    }

    if (!empty($searchQuery)) {
        $query .= " AND t.description LIKE ?";
        $params[] = "%$searchQuery%";
        $types .= 's';
    }

    if (!empty($startDate) && !empty($endDate)) {
        $query .= " AND t.transaction_date BETWEEN ? AND ?";
        $params[] = $startDate;
        $params[] = $endDate;
        $types .= 'ss';
    }

    // Add sorting and pagination
    $query .= " ORDER BY t.transaction_date DESC 
              LIMIT ? OFFSET ?";
    $offset = ($currentPage - 1) * $itemsPerPage;
    $params[] = $itemsPerPage;
    $params[] = $offset;
    $types .= 'ii';

    // Prepare and execute query
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $transactions = $result->fetch_all(MYSQLI_ASSOC);

    // Get total count
    $totalResult = $conn->query("SELECT FOUND_ROWS()");
    $totalRows = $totalResult->fetch_row()[0];
    $totalPages = ceil($totalRows / $itemsPerPage);

    // Get categories for filter dropdown
    $categoryStmt = $conn->prepare("SELECT * FROM categories WHERE user_id = ? OR is_default = 1");
    $categoryStmt->bind_param("i", $user_id);
    $categoryStmt->execute();
    $categories = $categoryStmt->get_result()->fetch_all(MYSQLI_ASSOC);

} catch (mysqli_sql_exception $e) {
    $error = "Error fetching transactions: " . $e->getMessage();
}

// Get user data from session
$first_name  = $_SESSION['first_name'] ?? 'User';
$profile_img = $_SESSION['profile_img'] ?? null;
$currency    = $_SESSION['currency'] ?? 'USD';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Transactions - SpendWise</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0">
  <style>
    .blue-monotone {
      background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
    }
    .input-focus:focus {
      box-shadow: 0 0 0 3px rgba(30, 58, 138, 0.3);
    }
    .transaction-row:hover {
      background-color: #f8fafc;
      transform: translateY(-2px);
    }
  </style>
</head>
<body class="bg-blue-50 min-h-screen p-4 pb-24">

  <!-- Success/Error Messages -->
  <?php if (isset($_SESSION['success'])): ?>
    <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
      <span class="material-symbols-rounded text-green-500">check_circle</span>
      <?= $_SESSION['success'] ?>
    </div>
    <?php unset($_SESSION['success']); ?>
  <?php endif; ?>

  <?php if (isset($_SESSION['error'])): ?>
    <div class="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
      <span class="material-symbols-rounded text-red-500">error</span>
      <?= $_SESSION['error'] ?>
    </div>
    <?php unset($_SESSION['error']); ?>
  <?php endif; ?>

  <!-- Header -->
  <div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold text-blue-900">Transaction History</h1>
    <div class="relative group" id="profileDropdown">
      <div class="w-10 h-10 rounded-full bg-blue-100 overflow-hidden flex items-center justify-center cursor-pointer shadow-sm">
        <?php if ($profile_img): ?>
          <img src="<?= htmlspecialchars($profile_img) ?>" class="w-full h-full object-cover">
        <?php else: ?>
          <span class="text-blue-800 font-semibold"><?= strtoupper(substr($first_name, 0, 1)) ?></span>
        <?php endif; ?>
      </div>
      <div class="absolute right-0 mt-2 w-48 bg-white border border-blue-100 rounded-lg shadow-xl opacity-0 invisible transition-all duration-300 z-50" 
           id="profileMenu">
        <a href="profile.php" class="block px-4 py-3 text-blue-800 hover:bg-blue-50">Profile</a>
        <a href="settings.php" class="block px-4 py-3 text-blue-800 hover:bg-blue-50">Settings</a>
        <form method="POST" action="logout.php">
          <button type="submit" class="w-full text-left px-4 py-3 text-blue-800 hover:bg-blue-50 border-t border-blue-100">
            Logout
          </button>
        </form>
      </div>
    </div>
  </div>

  <!-- Filters -->
  <div class="bg-white p-4 rounded-xl shadow-lg border border-blue-100 mb-6">
    <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
      <div>
        <label class="block text-sm font-medium text-blue-700 mb-2">Type</label>
        <select name="type" class="w-full px-3 py-2 border border-blue-200 rounded-lg input-focus">
          <option value="all" <?= $typeFilter === 'all' ? 'selected' : '' ?>>All Types</option>
          <option value="income" <?= $typeFilter === 'income' ? 'selected' : '' ?>>Income</option>
          <option value="expense" <?= $typeFilter === 'expense' ? 'selected' : '' ?>>Expense</option>
        </select>
      </div>
      
      <div>
        <label class="block text-sm font-medium text-blue-700 mb-2">Category</label>
        <select name="category" class="w-full px-3 py-2 border border-blue-200 rounded-lg input-focus">
          <option value="all" <?= $categoryFilter === 'all' ? 'selected' : '' ?>>All Categories</option>
          <?php foreach ($categories as $category): ?>
            <option value="<?= $category['category_id'] ?>" <?= $categoryFilter == $category['category_id'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($category['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div>
        <label class="block text-sm font-medium text-blue-700 mb-2">Date Range</label>
        <div class="flex gap-2">
          <input type="date" name="start_date" value="<?= $startDate ?>" 
                 class="w-1/2 px-3 py-2 border border-blue-200 rounded-lg input-focus">
          <input type="date" name="end_date" value="<?= $endDate ?>" 
                 class="w-1/2 px-3 py-2 border border-blue-200 rounded-lg input-focus">
        </div>
      </div>

      <div>
        <label class="block text-sm font-medium text-blue-700 mb-2">Search</label>
        <input type="text" name="search" value="<?= htmlspecialchars($searchQuery) ?>" 
               placeholder="Search descriptions..." 
               class="w-full px-3 py-2 border border-blue-200 rounded-lg input-focus">
      </div>

      <div class="md:col-span-4 flex justify-end gap-2">
        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          Apply Filters
        </button>
        <a href="transactions.php" class="px-4 py-2 border border-blue-200 text-blue-700 rounded-lg hover:bg-blue-50">
          Reset
        </a>
      </div>
    </form>
  </div>

  <!-- Transactions Table -->
  <div class="bg-white rounded-xl shadow-lg border border-blue-100 overflow-hidden">
    <div class="overflow-x-auto">
      <table class="w-full">
        <thead class="bg-blue-50">
          <tr>
            <th class="px-4 py-3 text-left text-sm font-medium text-blue-700">Date</th>
            <th class="px-4 py-3 text-left text-sm font-medium text-blue-700">Description</th>
            <th class="px-4 py-3 text-left text-sm font-medium text-blue-700">Category</th>
            <th class="px-4 py-3 text-left text-sm font-medium text-blue-700">Type</th>
            <th class="px-4 py-3 text-right text-sm font-medium text-blue-700">Amount</th>
            <th class="px-4 py-3 text-right text-sm font-medium text-blue-700">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($transactions as $transaction): ?>
            <tr class="transaction-row transition-all border-t border-blue-100">
              <td class="px-4 py-3 text-sm text-gray-700">
                <?= date('M j, Y', strtotime($transaction['transaction_date'])) ?>
              </td>
              <td class="px-4 py-3 text-sm text-gray-900 font-medium">
                <?= htmlspecialchars($transaction['description']) ?>
              </td>
              <td class="px-4 py-3 text-sm text-gray-700">
                <span class="inline-block w-2 h-2 rounded-full mr-2" 
                      style="background-color: <?= $transaction['color'] ?? '#CBD5E1' ?>"></span>
                <?= htmlspecialchars($transaction['category_name'] ?? 'Uncategorized') ?>
              </td>
              <td class="px-4 py-3 text-sm">
                <span class="px-2 py-1 rounded-full <?= $transaction['transaction_type'] === 'income' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                  <?= ucfirst($transaction['transaction_type']) ?>
                </span>
              </td>
              <td class="px-4 py-3 text-right text-sm font-medium <?= $transaction['transaction_type'] === 'income' ? 'text-green-600' : 'text-red-600' ?>">
                <?= ($transaction['transaction_type'] === 'income' ? '+' : '-') ?>
                <?= $currency ?> <?= number_format($transaction['amount'], 2) ?>
              </td>
              <td class="px-4 py-3 text-right space-x-2">
                <a href="edit-transaction.php?id=<?= $transaction['transaction_id'] ?>" 
                   class="px-2 py-1 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                  <i class="fas fa-edit"></i>
                </a>
                <form method="POST" action="delete-transaction.php" class="inline">
                  <input type="hidden" name="transaction_id" value="<?= $transaction['transaction_id'] ?>">
                  <button type="button" 
                          onclick="confirmDelete(this.form)" 
                          class="px-2 py-1 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                    <i class="fas fa-trash"></i>
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div class="border-t border-blue-100 px-4 py-3">
      <div class="flex justify-between items-center">
        <span class="text-sm text-gray-700">
          Page <?= $currentPage ?> of <?= $totalPages ?>
        </span>
        <div class="flex gap-2">
          <a href="?<?= http_build_query(array_merge($_GET, ['page' => $currentPage - 1])) ?>" 
             class="px-3 py-1 border border-blue-200 rounded-lg <?= $currentPage <= 1 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-50' ?>">
            Previous
          </a>
          <a href="?<?= http_build_query(array_merge($_GET, ['page' => $currentPage + 1])) ?>" 
             class="px-3 py-1 border border-blue-200 rounded-lg <?= $currentPage >= $totalPages ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-50' ?>">
            Next
          </a>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Floating Action Menu -->
  <div class="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50">
    <div class="flex gap-3 bg-white px-3 py-2 rounded-full shadow-xl border border-blue-100">
      <a href="add-expense.php" class="p-3 bg-blue-600 text-white rounded-full shadow-md hover:bg-blue-700">
        <span class="material-symbols-rounded">add</span>
      </a>
      <a href="dashboard.php" class="p-3 bg-blue-400 text-white rounded-full shadow-md hover:bg-blue-500">
        <span class="material-symbols-rounded">home</span>
      </a>
    </div>
  </div>

  <script>
  // Profile Dropdown Logic
  document.addEventListener('DOMContentLoaded', () => {
    const trigger = document.getElementById('profileDropdown');
    const menu = document.getElementById('profileMenu');

    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.classList.toggle('opacity-0');
      menu.classList.toggle('invisible');
      menu.classList.toggle('opacity-100');
      menu.classList.toggle('visible');
    });

    document.addEventListener('click', (e) => {
      if (!trigger.contains(e.target)) {
        menu.classList.add('opacity-0', 'invisible');
        menu.classList.remove('opacity-100', 'visible');
      }
    });
  });

  // Delete Confirmation
  function confirmDelete(form) {
    if (confirm('Are you sure you want to delete this transaction? This action cannot be undone.')) {
      form.submit();
    }
  }
  </script>
</body>
</html>