<?php
// Display all errors for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host = "sql207.infinityfree.com";
$dbname = "if0_38725960_spendwise";
$user = "if0_38725960";
$pass = "xAug0MJ9zyags"; // Replace with actual password

$conn = new mysqli($host, $user, $pass, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
  $email      = trim($_POST['email'] ?? '');
  $password   = trim($_POST['password'] ?? '');
  $first_name = trim($_POST['first_name'] ?? '');
  $last_name  = trim($_POST['last_name'] ?? '');
  $username   = trim($_POST['username'] ?? '');

  if ($email && $password && $first_name && $last_name && $username) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
      $error = "Email is already registered.";
    } else {
      $password_hash = password_hash($password, PASSWORD_BCRYPT);
      $stmt = $conn->prepare("INSERT INTO users (email, password_hash, first_name, last_name, username) VALUES (?, ?, ?, ?, ?)");
      $stmt->bind_param("sssss", $email, $password_hash, $first_name, $last_name, $username);

      if ($stmt->execute()) {
        // Send Welcome Email
        $mail = new PHPMailer(true);
        try {
          $mail->isSMTP();
          $mail->Host = 'smtp.gmail.com';
          $mail->SMTPAuth = true;
          $mail->Username = 'jahnviaghera@gmail.com';
          $mail->Password = 'hzychokfnnujpusf'; // ⚠️ Store this securely!
          $mail->SMTPSecure = 'tls';
          $mail->Port = 587;

          $mail->setFrom('jahnviaghera@gmail.com', 'SPendWise Team');
          $mail->addAddress($email, $username);

          $mail->isHTML(true);
          $mail->Subject = 'Welcome to SPendWise!';

          $mailBody = "
          <html>
          <head>
              <style>
                  body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                  .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                  .header { background: linear-gradient(135deg, #075985 0%, #0c4a6e 100%); color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
                  .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 5px 5px; }
                  .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
                  .button { display: inline-block; background: #0c4a6e; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
              </style>
          </head>
          <body>
              <div class='container'>
                  <div class='header'>
                      <h1>Welcome to SPendWise!</h1>
                  </div>
                  <div class='content'>
                      <p>Hello " . htmlspecialchars($username) . ",</p>
                      <p>Thank you for creating an account with SPendWise. We're excited to have you join our community!</p>
                      <ul>
                          <li>Track your expenses and income</li>
                          <li>Create and manage budgets</li>
                          <li>Set financial goals</li>
                          <li>Get insights about your spending</li>
                      </ul>
                      <p style='text-align: center; margin-top: 30px;'>
                          <a href='https://zenith24ttt.ct.ws/login.php' class='button'>Log In Now</a>
                      </p>
                      <p>Best regards,<br>The SPendWise Team</p>
                  </div>
                  <div class='footer'>
                      <p>&copy; " . date('Y') . " SPendWise. All rights reserved.</p>
                      <p>This email was sent to " . htmlspecialchars($email) . "</p>
                  </div>
              </div>
          </body>
          </html>
          ";

          $mail->Body = $mailBody;
          $mail->AltBody = "Welcome to SPendWise, $username! Log in at https://zenith24ttt.ct.ws/login.php";

          $mail->send();
          $success = "Account created successfully. A welcome email has been sent.";
        } catch (Exception $e) {
          $success = "Account created, but email couldn't be sent.";
          file_put_contents('email_error_log.txt', date('Y-m-d H:i:s') . " - Email error: " . $mail->ErrorInfo . "\n", FILE_APPEND);
        }
      } else {
        $error = "Failed to register user. Try again later.";
      }
    }
  } else {
    $error = "All fields are required.";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register - SPendWise</title>
  <meta name="theme-color" content="#0c4a6e">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
  .gradient-bg {
    background: linear-gradient(135deg, #075985 0%, #0c4a6e 100%);
  }
  .input-focus:focus {
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.3);
  }
  .transition-all {
    transition: all 0.3s ease;
  }
  </style>
</head>
<body class="gradient-bg flex items-center justify-center min-h-screen p-4">
  <div class="w-full max-w-md">
  <div class="bg-white rounded-2xl shadow-xl overflow-hidden transition-all transform hover:shadow-2xl">
    <div class="p-8">
    <div class="flex justify-center mb-6">
      <div class="bg-blue-100 p-3 rounded-full">
      <i class="fas fa-wallet text-blue-600 text-3xl"></i>
      </div>
    </div>
    <h2 class="text-3xl font-bold text-center text-gray-800 mb-2">Create Your Account</h2>
    <p class="text-center text-gray-600 mb-8">Start managing your finances smarter</p>

    <?php if ($error): ?>
      <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded">
      <div class="flex">
        <div class="flex-shrink-0">
        <i class="fas fa-exclamation-circle text-red-500"></i>
        </div>
        <div class="ml-3">
        <p class="text-sm text-red-700"><?= htmlspecialchars($error) ?></p>
        </div>
      </div>
      </div>
    <?php elseif ($success): ?>
      <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded">
      <div class="flex">
        <div class="flex-shrink-0">
        <i class="fas fa-check-circle text-green-500"></i>
        </div>
        <div class="ml-3">
        <p class="text-sm text-green-700"><?= htmlspecialchars($success) ?></p>
        </div>
      </div>
      </div>
    <?php endif; ?>

    <form method="POST">
      <div class="grid grid-cols-2 gap-4 mb-4">
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">First Name</label>
        <div class="relative">
        <input type="text" name="first_name" required
             class="pl-10 w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none">
        </div>
      </div>
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
        <div class="relative">
        <input type="text" name="last_name" required
             class="pl-10 w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none">
        </div>
      </div>
      </div>

      <div class="mb-4">
      <label class="block text-sm font-medium text-gray-700 mb-1">Username</label>
      <div class="relative">
        <div class="absolute inset-y-0 left-0 pl-3 flex items-center">
        <i class="fas fa-tag text-gray-400"></i>
        </div>
        <input type="text" name="username" required
           class="pl-10 w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none">
      </div>
      </div>

      <div class="mb-4">
      <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
      <div class="relative">
        <div class="absolute inset-y-0 left-0 pl-3 flex items-center">
        <i class="fas fa-envelope text-gray-400"></i>
        </div>
        <input type="email" name="email" required
           class="pl-10 w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none">
      </div>
      </div>

      <div class="mb-4">
      <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
      <div class="relative">
        <div class="absolute inset-y-0 left-0 pl-3 flex items-center">
        <i class="fas fa-lock text-gray-400"></i>
        </div>
        <input type="password" name="password" required
           class="pl-10 w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none">
      </div>
      </div>

      <button type="submit"
          class="w-full gradient-bg text-white py-3 px-4 rounded-lg font-medium hover:opacity-90 transition-all flex items-center justify-center">
      <i class="fas fa-user-plus mr-2"></i> Create Account
      </button>
    </form>

    <div class="mt-6">
      <div class="g_id_signin"
         data-type="standard"
         data-shape="pill"
         data-theme="outline"
         data-text="sign_up_with"
         data-size="large"
         data-logo_alignment="left">
      </div>
    </div>

    <div class="mt-8 border-t border-gray-200 pt-6 text-center">
      <p class="text-sm text-gray-600">
      Already have an account? 
      <a href="https://zenith24ttt.ct.ws/login.php" class="font-medium text-blue-600 hover:underline">Sign in</a>
      </p>
    </div>
    </div>
  </div>

  <div class="mt-6 text-center text-white text-sm">
    <p>&copy; <?= date('Y') ?> SpendWise. All rights reserved.</p>
  </div>
  </div>
</body>
</html>
