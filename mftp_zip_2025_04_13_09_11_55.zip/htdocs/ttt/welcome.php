<?php
// Get parameters from the URL
$email = $_REQUEST['email'] ?? '';
$username = $_REQUEST['username'] ?? '';

// Verify that we have the required parameters
if (empty($email)) {
    die("Error: Email address is required");
}

// Set up PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'jahnviaghera@gmail.com';
    $mail->Password = 'hzychokfnnujpusf';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    // Recipients
    $mail->setFrom('jahnviaghera@gmail.com', 'SPendWise Team');
    $mail->addAddress($email, $username);

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Welcome to SPendWise!';
    
    // Create a nice HTML welcome email
    $mailBody = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #075985 0%, #0c4a6e 100%); color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
            .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 5px 5px; }
            .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
            .button { display: inline-block; background: #0c4a6e; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>Welcome to SpendWise!</h1>
            </div>
            <div class='content'>
                <p>Hello " . htmlspecialchars($username) . ",</p>
                <p>Thank you for creating an account with SpendWise. We're excited to have you join our community!</p>
                <p>With your new account, you can start managing your finances smarter:</p>
                <ul>
                    <li>Track your expenses and income</li>
                    <li>Create and manage budgets</li>
                    <li>Set financial goals</li>
                    <li>Generate insights about your spending habits</li>
                </ul>
                <p style='text-align: center; margin-top: 30px;'>
                    <a href='https://zenith24ttt.ct.ws/login.php' class='button'>Log In Now</a>
                </p>
                <p>If you have any questions or need assistance, please don't hesitate to contact our support team.</p>
                <p>Best regards,<br>The SpendWise Team</p>
            </div>
            <div class='footer'>
                <p>&copy; " . date('Y') . " SpendWise. All rights reserved.</p>
                <p>This email was sent to " . htmlspecialchars($email) . "</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    $mail->Body = $mailBody;
    $mail->AltBody = "Welcome to SpendWise, " . $username . "! Thank you for creating an account with us. You can now log in to start managing your finances smarter.";

    $mail->send();
    echo "Welcome email sent to " . htmlspecialchars($email);
    
    // Log the successful email for your records (optional)
    file_put_contents('email_log.txt', date('Y-m-d H:i:s') . " - Welcome email sent to: " . $email . " (" . $username . ")\n", FILE_APPEND);
    
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    
    // Log the error (optional)
    file_put_contents('email_error_log.txt', date('Y-m-d H:i:s') . " - Error sending to: " . $email . " - " . $mail->ErrorInfo . "\n", FILE_APPEND);
}
?>