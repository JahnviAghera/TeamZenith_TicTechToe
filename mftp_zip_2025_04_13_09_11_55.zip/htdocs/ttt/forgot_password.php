<?php
// Display all errors for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host = "sql207.infinityfree.com";
$dbname = "if0_38725960_spendwise";
$user = "if0_38725960";
$pass = "xAug0MJ9zyags"; // Replace with actual password

$conn = new mysqli($host, $user, $pass, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
require __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address";
    } else {
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            $token = bin2hex(random_bytes(50));
            $expires = date("Y-m-d H:i:s", time() + 3600); // 1 hour expiration

            // Store token in database
            $stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE user_id = ?");
            $stmt->bind_param("ssi", $token, $expires, $user['user_id']);
            
            if ($stmt->execute()) {
                // Send email using PHPMailer
                $mail = new PHPMailer(true);
                
                try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'jahnviaghera@gmail.com';
    $mail->Password = 'hzychokfnnujpusf';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

                    // Recipients
                    $mail->setFrom(FROM_EMAIL, FROM_NAME);
                    $mail->addAddress($email);

                    // Content
                    $resetLink = "https://zenith24ttt.ct.ws/reset-password.php?token=$token";
                    $mail->isHTML(true);
                    $mail->Subject = 'Password Reset Request';
                    $mail->Body    = "
                        <h2>Password Reset Request</h2>
                        <p>Please click the link below to reset your password:</p>
                        <p><a href='$resetLink'>$resetLink</a></p>
                        <p>This link will expire in 1 hour.</p>
                    ";
                    $mail->AltBody = "Reset your password using this link: $resetLink";

                    $mail->send();
                    $success = "Password reset instructions sent to your email";
                } catch (Exception $e) {
                    error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
                    $error = "Failed to send reset email. Please try again later.";
                }
            } else {
                $error = "Error initiating password reset";
            }
        } else {
            $error = "No account found with this email address";
        }
    }
}
?>