<?php
// floating-button.php
// This creates a fixed floating chat button in the bottom right corner

header('Content-Type: application/javascript');
?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Create the container div for the button
    var buttonContainer = document.createElement('div');
    buttonContainer.id = 'getbutton-container';
    buttonContainer.style.position = 'fixed';
    buttonContainer.style.bottom = '20px';
    buttonContainer.style.right = '20px';
    buttonContainer.style.zIndex = '9999';
    
    // Append the container to the body
    document.body.appendChild(buttonContainer);
    
    // Create the script element
    var script = document.createElement('script');
    script.defer = true;
    script.src = 'https://static.getbutton.io/widget/bundle.js?id=qYniS';
    
    // Append the script to the container
    buttonContainer.appendChild(script);
    
    // Optional: Add some basic styling for the button
    var style = document.createElement('style');
    style.textContent = `
        .getbutton-ui {
            transition: all 0.3s ease;
        }
        .getbutton-ui:hover {
            transform: scale(1.05);
        }
        @media (max-width: 768px) {
            #getbutton-container {
                bottom: 15px;
                right: 15px;
            }
        }
    `;
    document.head.appendChild(style);
});
</script>