<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Display all errors for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host = "sql207.infinityfree.com";
$dbname = "if0_38725960_spendwise";
$user = "if0_38725960";
$pass = "xAug0MJ9zyags"; // Replace with actual password

$pdo = new mysqli($host, $user, $pass, $dbname);

// Check for connection errors
if ($pdo->connect_error) {
    die("Connection failed: " . $pdo->connect_error); // Use $pdo->connect_error, not $conn
}

$user_id = $_SESSION['user_id'];

try {
    // Current Month's Spend
    $stmt = $pdo->prepare("
        SELECT SUM(amount) AS total 
        FROM transactions 
        WHERE user_id = ? 
        AND transaction_type = 'expense'
        AND MONTH(transaction_date) = MONTH(CURRENT_DATE())
        AND YEAR(transaction_date) = YEAR(CURRENT_DATE())
    ");
    $stmt->bind_param("i", $user_id); // binding the user_id as integer
    $stmt->execute();
    $result = $stmt->get_result();  // Get the result set
    $current_spend = $result->fetch_assoc()['total'] ?? 0; // Correct usage of fetch_assoc()

    // Monthly Budget
    $stmt = $pdo->prepare("
        SELECT SUM(amount) AS total 
        FROM budgets 
        WHERE user_id = ? 
        AND period = 'monthly'
        AND (start_date <= CURDATE() AND (end_date IS NULL OR end_date >= CURDATE()))
    ");
    $stmt->bind_param("i", $user_id); // binding the user_id as integer
    $stmt->execute();
    $result = $stmt->get_result();
    $monthly_budget = $result->fetch_assoc()['total'] ?? 0;  // fetch_assoc for mysqli

    // Recent Transactions (last 5)
    $stmt = $pdo->prepare("
        SELECT t.*, c.name AS category_name, c.color 
        FROM transactions t
        LEFT JOIN categories c ON t.category_id = c.category_id
        WHERE t.user_id = ? 
        ORDER BY t.transaction_date DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $transactions = [];
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;  // Collect transactions
    }

    // Budgets with Progress
    $stmt = $pdo->prepare("
        SELECT b.*, c.name AS category_name,
        (SELECT COALESCE(SUM(amount), 0)
         FROM transactions
         WHERE user_id = b.user_id
         AND category_id = b.category_id
         AND transaction_type = 'expense'
         AND MONTH(transaction_date) = MONTH(CURRENT_DATE())
         AND YEAR(transaction_date) = YEAR(CURRENT_DATE())) AS spent
        FROM budgets b
        LEFT JOIN categories c ON b.category_id = c.category_id
        WHERE b.user_id = ?
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $budgets = [];
    while ($row = $result->fetch_assoc()) {
        $budgets[] = $row;  // Collect budgets
    }

    // Financial Goals
    $stmt = $pdo->prepare("SELECT * FROM financial_goals WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $goals = [];
    while ($row = $result->fetch_assoc()) {
        $goals[] = $row;  // Collect goals
    }

    // Notifications
    $stmt = $pdo->prepare("
        SELECT * FROM notifications 
        WHERE user_id = ? AND is_read = 0
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = [];
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;  // Collect notifications
    }

    // Category Spending
    $stmt = $pdo->prepare("
        SELECT c.name, SUM(t.amount) AS total 
        FROM transactions t
        JOIN categories c ON t.category_id = c.category_id
        WHERE t.user_id = ? 
        AND t.transaction_type = 'expense'
        AND MONTH(t.transaction_date) = MONTH(CURRENT_DATE())
        AND YEAR(t.transaction_date) = YEAR(CURRENT_DATE())
        GROUP BY c.name
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $categories = [];
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;  // Collect category data
    }

} catch (mysqli_sql_exception $e) {
    die("Error fetching data: " . $e->getMessage());
}

// Get user data from session
$first_name  = $_SESSION['first_name'] ?? 'User';
$last_name   = $_SESSION['last_name'] ?? '';
$email       = $_SESSION['email'] ?? '';
$username    = $_SESSION['username'] ?? '';
$currency    = $_SESSION['currency'] ?? 'USD';
$profile_img = $_SESSION['profile_img'] ?? null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - SpendWise</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0">
  <style>
    .blue-monotone {
      background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
    }
    .progress-bar {
      transition: width 0.5s ease-in-out;
    }
  </style>
</head>
<body class="bg-blue-50 min-h-screen p-4 pb-24">

  <!-- Header -->
  <div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold text-blue-900">Welcome back, <?= htmlspecialchars($first_name) ?> 👋</h1>
    <div class="flex gap-2">
      <!-- Profile Dropdown -->
      <div class="relative group" id="profileDropdown">
        <div class="w-10 h-10 rounded-full bg-blue-100 overflow-hidden flex items-center justify-center cursor-pointer shadow-sm">
          <?php if ($profile_img): ?>
            <img src="<?= htmlspecialchars($profile_img) ?>" alt="Profile" class="w-full h-full object-cover">
          <?php else: ?>
            <span class="text-blue-800 font-semibold"><?= strtoupper(substr($first_name, 0, 1)) ?></span>
          <?php endif; ?>
        </div>
        <!-- Dropdown Menu -->
        <div class="absolute right-0 mt-2 w-48 bg-white border border-blue-100 rounded-lg shadow-xl opacity-0 invisible transition-all duration-300 z-50" 
             id="profileMenu">
          <a href="profile.php" class="block px-4 py-3 text-blue-800 hover:bg-blue-50">Profile</a>
          <a href="settings.php" class="block px-4 py-3 text-blue-800 hover:bg-blue-50">Settings</a>
          <form method="POST" action="logout.php">
            <button type="submit" class="w-full text-left px-4 py-3 text-blue-800 hover:bg-blue-50 border-t border-blue-100">
              Logout
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Main Content -->
  <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
    <!-- Left Column -->
    <div class="lg:col-span-2 space-y-4">
      <!-- Stats Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div class="blue-monotone p-5 rounded-xl shadow-lg text-white">
          <h3 class="text-sm font-medium">Monthly Spend</h3>
          <p class="text-2xl font-bold mt-1">
            <?= $currency ?> <?= number_format($current_spend, 2) ?>
          </p>
        </div>
        <div class="bg-white p-5 rounded-xl shadow-lg border border-blue-100">
          <h3 class="text-sm font-medium text-blue-700">Monthly Budget</h3>
          <p class="text-2xl font-bold text-blue-900 mt-1">
            <?= $currency ?> <?= number_format($monthly_budget, 2) ?>
          </p>
        </div>
      </div>

<!-- Budget Progress -->
<div class="bg-white p-5 rounded-xl shadow-md border border-blue-100">
  <h3 class="text-lg font-semibold text-blue-900 mb-4">Budget Progress</h3>
  <div class="space-y-5">
    <?php foreach ($budgets as $budget): ?>
      <?php 
        $progress = $budget['amount'] > 0 ? ($budget['spent'] / $budget['amount']) * 100 : 0;
        $progress = min($progress, 100);
        $progress_color = $progress >= 80 ? 'bg-blue-800' : 
                         ($progress > 60 ? 'bg-blue-600' : 'bg-blue-400');
      ?>
      <div class="flex items-center justify-between">
        <!-- Category and Spent Info -->
        <div>
          <div class="text-sm font-medium text-blue-700">
            <?= htmlspecialchars($budget['category_name'] ?? 'No Category') ?>
          </div>
          <div class="text-xs text-gray-500">
            <?= number_format($budget['spent'], 2) ?> / <?= number_format($budget['amount'], 2) ?>
          </div>
        </div>
        <!-- Percentage -->
        <div class="text-sm font-semibold text-blue-800">
          <?= round($progress) ?>%
        </div>
      </div>
      <!-- Progress Bar -->
      <div class="w-full bg-blue-100 rounded-full h-2">
        <div class="h-2 rounded-full <?= $progress_color ?>" style="width: <?= $progress ?>%"></div>
      </div>
    <?php endforeach; ?>
  </div>
</div>


      <!-- Recent Transactions -->
<div class="bg-white p-5 rounded-xl shadow-lg border border-blue-100">
  <div class="flex justify-between items-center mb-3">
    <h3 class="text-lg font-semibold text-blue-900">Recent Transactions</h3>
    <a href="https://zenith24ttt.ct.ws/transaction.php" class="text-sm text-gray-500 hover:text-gray-700">View All</a>
  </div>
  <div class="space-y-2">
    <?php foreach ($transactions as $transaction): ?>
      <div class="flex justify-between items-center p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
        <div class="space-y-0.5">
          <p class="font-medium text-blue-900">
            <?= htmlspecialchars($transaction['description']) ?>
          </p>
          <p class="text-xs text-blue-600">
            <?= htmlspecialchars($transaction['category_name']) ?> • 
            <?= date('M j, Y', strtotime($transaction['transaction_date'])) ?>
          </p>
        </div>
        <span class="text-sm font-semibold <?= $transaction['transaction_type'] === 'income' ? 'text-blue-600' : 'text-red-600' ?>">
          <?= $transaction['transaction_type'] === 'income' ? '+' : '-' ?>
          <?= $currency ?> <?= number_format($transaction['amount'], 2) ?>
        </span>
      </div>
    <?php endforeach; ?>
  </div>
</div>
          
    </div>

    <!-- Right Column -->
    <div class="space-y-4">
      <!-- Category Chart -->
      <div class="bg-white p-5 rounded-xl shadow-lg border border-blue-100">
        <h3 class="text-lg font-semibold text-blue-900 mb-3">Spending by Category</h3>
        <canvas id="categoryChart" class="w-full" height="200"></canvas>
      </div>
    </div>
  </div>

  <!-- Floating Action Menu -->
  <div class="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50">
    <div class="flex gap-3 bg-white px-3 py-2 rounded-full shadow-xl border border-blue-100">
      <a href="add-expense.php" class="p-3 bg-blue-600 text-white rounded-full shadow-md hover:bg-blue-700 transition-colors">
        <span class="material-symbols-rounded">add</span>
      </a>
      <a href="add-budget.php" class="p-3 bg-blue-500 text-white rounded-full shadow-md hover:bg-blue-600 transition-colors">
        <span class="material-symbols-rounded">savings</span>
      </a>
      <a href="export-data.php" class="p-3 bg-blue-400 text-white rounded-full shadow-md hover:bg-blue-500 transition-colors">
        <span class="material-symbols-rounded">bar_chart</span>
      </a>
    </div>
  </div>
<!-- Debug - remove after testing 
<div class="text-xs bg-gray-100 p-2 mb-2 rounded">
  <?php 
  echo "Categories data:<br>";
  foreach ($categories as $cat) {
    echo htmlspecialchars($cat['name']) . ": " . 
         htmlspecialchars($cat['total']) . " (type: " . gettype($cat['total']) . ")<br>";
  }
  ?>
</div>-->
<script>
// Profile Dropdown Logic
document.addEventListener('DOMContentLoaded', () => {
  const trigger = document.getElementById('profileDropdown');
  const menu = document.getElementById('profileMenu');

  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    menu.classList.toggle('opacity-0');
    menu.classList.toggle('invisible');
    menu.classList.toggle('opacity-100');
    menu.classList.toggle('visible');
  });

  document.addEventListener('click', (e) => {
    if (!trigger.contains(e.target)) {
      menu.classList.add('opacity-0', 'invisible');
      menu.classList.remove('opacity-100', 'visible');
    }
  });
});

// Category Chart
const ctx = document.getElementById('categoryChart').getContext('2d');
new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: <?= json_encode(array_column($categories, 'name')) ?>,
        datasets: [{
            data: <?= json_encode(array_map('floatval', array_column($categories, 'total'))) ?>,
            backgroundColor: [
              '#1e3a8a', '#1e40af', '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd'
            ],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        cutout: '70%',
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    color: '#1e3a8a',
                    font: {
                        weight: '500'
                    }
                }
            }
        }
    }
});
</script>

</body>
</html>